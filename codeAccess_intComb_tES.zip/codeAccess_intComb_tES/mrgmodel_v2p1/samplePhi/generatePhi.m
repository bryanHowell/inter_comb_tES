% This script takes in acr lengths for MRG model and outputs sample phi
% Author: Bryan Howell, Ph.D.
% Date: 12/05/2018

%% files and directories

workDir = pwd;
geomDir = '/home/bryan/Desktop/elecStimIIFs/mrgmodel_v2p1/mrgGeom';
pSourceDir = '/home/bryan/Desktop/elecStimIIFs/pointSourceStim';

geomFile = 'arclength_mrgmod_D3_L60.txt';
phiFile = ['PhiPS1mm_',geomFile];

%% load data

xaPre = load([geomDir, '/', geomFile]);
numPts = length(xaPre);

%% generate potentials
% we want the max. potential to be 1 V so that we have the unit sln

% model parameters
Istim = 1e-3; % mA => A
sig = 0.2e-3; % S/m => S/mm
phiMax = 1; % V
rMin = 1;%Istim / 4 / pi / sig / phiMax; % mm

% generate axonal coordinates
xa = xaPre - xaPre((numPts + 1) / 2);
ya = rMin * ones(1, numPts);
za = zeros(size(xa));
xyz = [xa; ya; za];

cd(pSourceDir);
phi = pointSource(xyz, [0; 0; 0], sig, Istim);
cd(workDir);

%% save file

dlmwrite(phiFile, [zeros(numPts,1), phi'], 'delimiter', ' ', 'precision', 8);
