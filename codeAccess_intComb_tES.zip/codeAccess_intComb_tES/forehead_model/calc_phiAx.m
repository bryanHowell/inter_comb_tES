% Author: Bryan Howell, PhD
% Created: 11/17/2020
%
% Short description:
% Calculates potentials of axon in a semi-infinite medium with disk elec.
% Potentials are smoothed at ends so that end activaiton is minimized.

[A, B, C] = meshgrid(2:6, 5:7, 150);
param = [A(:), B(:), C(:)];
% param = [12, 6, 150];
numParam = size(param);

for k = 1:numParam
    
% clear;
% clc;

%% model parameters

% axon
D = param(k,1);%8; % fibere diameter of axon [um]
dAxon = param(k,2);%5; % depth of axon [mm]
L = param(k,3);%150; % length of axon [mm]

if(L == 150)
    side = 'oneSide';
    s = 0; % axon goes from zero to L
else
    side = 'twoSide';
    s = 1; % axon goes from -L/2 to L/2
end

%% file info

workDir = pwd;
mrgDir = '/home/bryan/Desktop/researchScientist/codeRepos/fitgeom_mrgmodel';

%% ideal disk electrode

in2mm = 25.4; % 25.4 mm in 1"
dElec = 3*in2mm; % [mm]

% get arc lengths coordinates for MRG model
cd(mrgDir);
arcMRG = myeaxon_xyz(D, L*1e3, s);    
cd(workDir);

% define xyz coordinates of axon in disk stim model
x = arcMRG;
y = zeros(size(x));
z = -dAxon * ones(size(x));

% calculatle electric potentials
phi = phi_diskElec(x, y, z, dElec/2, 1);

% sample data at Nodes of Ranvier
% One node every 8 elements
% Node - MYSA - FLUT - STIN x3 - FLUT - MYSA - Node - ...
xNode = x(1:8:end);
phiNode = phi(1:8:end);
iKeep = xNode < 0.83 * L;
xTmp = xNode(iKeep);
xSamp = [xTmp, xNode(end)];
yTmp = phiNode(iKeep);
ySamp = [yTmp, 0.93 * yTmp(end)];

phiNewNode = csaps(xSamp, ySamp, 1, xNode);
phiNew = csaps(xSamp, ySamp, 1, x);

sd1 = -1*1e3*[diff(phiNode(1:2)), diff(phiNode,2), diff(phiNode(end-1:end))];
sd2 = -1*1e3*[diff(phiNewNode(1:2)), diff(phiNewNode,2), diff(phiNewNode(end-1:end))];

hold on;
plot(sd1, 'k');
plot(sd2, 'b');
hold off;

M = [zeros(length(phiNew),1), phiNew'];
% M = [zeros(length(phi),1), phi'];
fName = ['phiDiskEndSmth_z', num2str(dAxon), 'mm_D', num2str(D),...
    'um_L', num2str(L),'mm_', side, '.txt'];
dlmwrite(fName, M, 'delimiter', ' ');

end