function [phi] = phi_diskElec(x, y, z, a, Vo)
% Author: Bryan Howell, PhD
% Created: 11/17/2020
%
% INPUTS:
% x/y/z, Cartesian coordinates [mm]
% a, disk radius [mm]
% Vo, applied voltage [V]
%
% OUTPUTS:
% phi, potentials [V]

%% calculate phi
% ref1: Newman, Technical Notes, 1966
% ref2: Wiley and Webster, IEEE TBME, 1982
% ref3: Greenberg et al., IEEE TBME, 1999
% ref4: Wang et al., IEEE TBME, 2014

r = sqrt(x.^2 + y.^2 + z.^2);
phi = (2 * Vo / pi) * asin (2 * a ./ (sqrt((r - a).^2 + z.^2) + sqrt((r + a).^2 + z.^2)));

