%% forehead tES model
% Author: Bryan Howell, Ph.D.
% Created: 11/12/2020
%
% Short description:
% 2D Axisymmetric model of disk inside a ring. The disk and ring are
% seperate sources, and the ring is for a DC block.

clear;
clc;

%% setup COMSOL model

workDir = pwd;

% import libraries
import com.comsol.model.*
import com.comsol.model.util.*

model=ModelUtil.create('Model');
model.modelPath(workDir);
model.modelNode.create('comp1');
model.geom.create('geom1',2); % # dimensions
model.geom('geom1').axisymmetric(true); % axisymmetric
model.modelNode('comp1').sorder('cubic'); % shape fxn order

model.mesh.create('mesh1','geom1'); % mesh object 
model.physics.create('ec','ConductiveMedia','geom1');

model.study.create('std1');
model.study('std1').create('stat', 'Stationary'); % electrostatic
model.study('std1').feature('stat').activate('ec', true);
model.geom('geom1').lengthUnit('mm'); % length scale mm

%% model setup (parameters)
% layers: skin (1), fat (2), muscle (3), tendon (4), bone (5), CSF (6),
% brain (7)

% constants
e_o = 8.85e-12; % permittivity of free space [F/m]

% head parameters
% average circumference of human head is 56 cm
d_head = 560/pi; % [mm]

% sponge parameters
in2mm = 25.4; % 25.4 mm in 1"
d_disk = 1*in2mm;
dr_space = 2*in2mm; % radial thickness of spacing
dr_ring = 1*in2mm; % radial thickness of ring

% electrical properties
sig_tiss = 2e-3; % (S/m)

%% GEOMETRY

del_domain = [d_disk/2, dr_space, dr_ring, -1];
del_domain(end) = d_head - sum(del_domain(1:end-1));
del_cumsum = [0, cumsum(del_domain)];
numDom = length(del_domain);

% tissue domains
for k = 1:numDom
    model.geom('geom1').create(['r', num2str(k)], 'Rectangle');
    model.geom('geom1').feature(['r', num2str(k)]).set('size', [del_domain(k), d_head]);
    model.geom('geom1').feature(['r', num2str(k)]).set('pos', [del_cumsum(k), 0]);
end

% build geometries
model.geom('geom1').run;

figure;
mphgeom(model, 'geom1', 'facealpha', 0.2);
axis square;

%% MATERIALS

model.material.create('tiss', 'Common', 'comp1');
model.material('tiss').propertyGroup('def').set('electricconductivity', sig_tiss);
model.material('tiss').propertyGroup('def').set('relpermittivity', 1);

%% BOUNDARY CONDITIONS

dx = 1; % delta move for bounding boxes

% disk boundary
c1 = [0, d_head]';
c2 = [d_disk/2, d_head]';
bndDisk = mphselectbox(model, 'geom1', [c1-dx, c2+dx], 'boundary');

% ring (Anode and Cathode)
c1 = [del_cumsum(3), d_head]';
c2 = [del_cumsum(4), d_head]';
bndRingA = mphselectbox(model, 'geom1', [c1-dx, c2+dx], 'boundary');

% ground
c1 = [0, 0]';
c2 = [d_disk/2, 0]';
bndGnd = mphselectbox(model, 'geom1', [c1-dx, c2+dx], 'boundary');

model.physics('ec').feature.create('disk', 'ElectricPotential', 1);
model.physics('ec').feature('disk').selection.set(bndDisk);
model.physics('ec').feature('disk').set('V0', 0.5);
model.physics('ec').feature.create('ringA', 'ElectricPotential', 1);
model.physics('ec').feature('ringA').selection.set(bndRingA);
model.physics('ec').feature('ringA').set('V0', -0.5);
model.physics('ec').feature.create('Gnd', 'ElectricPotential', 1);
model.physics('ec').feature('Gnd').selection.set(bndGnd);


%% MESH

model.mesh('mesh1').create('ftri1','FreeTri');
model.mesh('mesh1').feature('size').set('hauto',1);
model.mesh('mesh1').run;

model.mesh('mesh1').stat.selection.geom('geom1',2);
model.mesh('mesh1').stat.selection.set(1:3);
mstat_all=mphmeshstats(model,'mesh1');
mstat.numele_total=mstat_all.numelem(2);

%% SOLVE

model.sol.create('sol1');
model.sol('sol1').study('std1');

model.study('std1').feature('stat').set('notlistsolnum',1);
model.study('std1').feature('stat').set('notsolnum','1');
model.study('std1').feature('stat').set('listsolnum',1);
model.study('std1').feature('stat').set('solnum','1');

model.sol('sol1').create('st1', 'StudyStep');
model.sol('sol1').feature('st1').set('study','std1');
model.sol('sol1').feature('st1').set('studystep','stat');
model.sol('sol1').create('v1', 'Variables');
model.sol('sol1').feature('v1').set('control','stat');
model.sol('sol1').create('s1', 'Stationary');
model.sol('sol1').feature('s1').create('fc1','FullyCoupled');
model.sol('sol1').feature('s1').feature('fc1').set('linsolver','dDef');
model.sol('sol1').feature('s1').feature.remove('fcDef');
model.sol('sol1').attach('std1');
model.sol('sol1').runAll;

%% PROCESS

% axon parameters
D = 10; % fibere diameter of axon [um]
L = 150; % length of axon [mm]
dAxon = 6; % depth of axon [mm]

% get arc lengths coordinates for MRG model
mrgDir = '/home/bryan/Desktop/researchScientist/codeRepos/fitgeom_mrgmodel';
cd(mrgDir);
arcMRG = myeaxon_xyz(D, L*1e3, 0);
cd(workDir);

% define axon
xAx = arcMRG;
yAx = zeros(size(xAx));
rAx = sqrt(xAx.^2 + yAx.^2);
zAx = (d_head - dAxon) * ones(size(xAx));

phiAx = mphinterp(model, 'V', 'coord', [rAx; zAx]);
phiNode = phiAx(1:8:end);
figure;
subplot(2,1,1);plot(phiNode);
subplot(2,1,2);plot(1e3*[diff(phiNode(1:2)), diff(phiNode,2), diff(phiNode(end-1:end))]);

jDisk = mphint2(model,'ec.normJ','line','selection', bndDisk);
iDisk = pi * d_disk * jDisk;

M = [zeros(length(phiAx),1), phiAx'];
fName = ['phiDiskRing_z', num2str(dAxon), 'mm_D', num2str(D),...
    'um_L', num2str(L),'mm.txt'];
dlmwrite(fName, M, 'delimiter', ' ');

% Z = mphinterp(model, 'V', 'coord', [0; 91]) / 1e-3;
% E = mphinterp(model, 'ec.normE', 'coord', [0; zProbe]);
