function [s, e] = calc_GabrielElecProp(f, tiss)
% Author: Bryan Howell, PhD
% Created: 11/16/2020
%
% INPUTS:
% f, frequency [Hz]
% tiss, tissue of interest (1-17)
% 1. blood
% 2. bone1 (cancellous / spongy)
% 3. bone2 (cortical / hard)
% 4. brain1 (grey matter)
% 5. brain2 (white matter)
% 6. fat1 (infiltrated)
% 7. fat2 (not infiltrated)
% 8. heart
% 9. kidney
% 10. lens
% 11. liver
% 12. lung (inflated)
% 13. muscle
% 14. skin1 (dry)
% 15. skin2 (wet) *
% 16. spleen
% 17. tendon
%
% OUTPUTS:
% s, sigma [S/m]
% e, permittivity, [F/m]
%
% *NOTE: skin2 uses alternate model by Raicu

%% constants / independent variable

e_o = 8.85e-12; % permittivity of free space [F/m]
w = 2 * pi * f; % angular frequency (Hz)

%% dispersion model
% ref: Gabriel et al., Physics in Med & Biol, 1996 (Part III)
% Cole-Cole Dispersion Model
% Equation
% e_hat = e_inf + e_k / (del_e_k + (j*w*tau_k^(1-alpha_k))) + sig_i / (j*w*e_o)

% Individual Terms
% e, permittivity
% e_hat, complex ""
% e_inf, permittivity at f => infinity
% del_e_k, change of permittivity over kth dispersion
% j, complex number
% w, angular frequency
% tau_k, time constant of kth dispersion
% 1 - alpha_k, rate of increase
% sig_i, static ionic conducitivity (at f = 0, DC)
% e_o, permittivity of free space
% k, counting index

% Dispersions (for reference)
% k = 1-4 (four dispersions)
% alpha, k = 1 (Hz)
% beta, k = 2 (kHz)
% gamma, k = 3 (MHz)
% delta, k = 4 (GHz)

% Parameter Table (Table 1 in ref)
% rows: 17 tissues in alphabetical order
% columns: 4 dispersions (alpha, beta, gamma, delta)

% permittivity at f => infinity
e_inf = [4, 2.5, 2.5, 4, 4, 2.5, 2.5, 4, 4, 4, 4, 2.5, 4, 4, 4, 4, 4]';

% dispersion 1 (tau_1 in ps)
del_e_1 = [56, 18, 10, 45, 32, 9, 3, 50, 47, 42, 39, 18, 50, 32, 39, 48, 42]';
tau_1 = 1e-12*[8.38, 13.26*ones(1,2), 7.96*ones(1,7), 8.84, 7.96, 7.23*ones(1,2), 7.96*ones(1,2), 12.24]';
alpha_1 = [0.1, 0.22, 0.2, 0.1, 0.1, 0.2, 0.2, 0.1*ones(1,6), 0, 0.1, 0.1, 0.1]';

% dispersion 2 (tau_2 in ns)
del_e_2 = [5200, 300, 180, 400, 100, 35, 15, 1200, 3500, 1500, 6e3, 500, 7e3, 1100, 280, 2500, 60]';
tau_2 = 1e-9*[132.63, 79.58, 79.58, 15.92, 7.96, 15.92*ones(1,2), 159.15,...
    198.94, 79.58, 530.52, 63.66, 353.86, 32.48, 79.58, 63.66, 6.37]';
alpha_2 = [0.1, 0.25, 0.2, 0.15, 0.1*ones(1,3), 0.05, 0.22, 0.1, 0.2, 0.1, 0.1, 0.2, 0, 0.15, 0.1]';

% dispersion 3 (tau_3 in us)
del_e_3 = [0, 2e4, 5e3, 2e5, 4e4, 3.3e4*ones(1,2), 4.5e5, 2.5e5, 2e5, 5e4, 2.5e5, 1.2e6, 0, 3e4, 2e5, 6e4]';
tau_3 = 1e-6*[0, 159.15*ones(1,2), 106.1, 53.05, 159.15*ones(1,2), 72.34, ...
    79.58, 159.15, 22.74, 159.15, 318.31, 0, 1.59, 265.26, 318.31]';
alpha_3 = [0, 0.2, 0.2, 0.22, 0.3, 0.05, 0.05, 0.22, 0.22, 0.1, 0.2, 0.2, 0.1, 0, 0.16, 0.25, 0.22]';

% dispersion 4 (tau_4 in ms)
del_e_4 = [0, 2e7, 1e5, 4.5e7, 3.5e7, 1e7, 1e7, 2.5e7, 3e7, 4e7, 3e7, 4e7, 2.5e7, 0, 3e4, 5e7, 2e7]';
tau_4 = 1e-3*[0, 15.915*ones(1,2), 5.305, 7.958, 15.915, 7.958, 4.547*ones(1,2),...
    15.915*ones(1,2), 7.958, 2.274, 0, 1.592, 6.366, 1.326]';
alpha_4 = [zeros(1,4), 0.02, 0.01, 0.01, zeros(1,3), 0.05, zeros(1,3), 0.2, 0, 0]';

% static ionic conductivity (at DC)
sig_i = [0.7, 0.07, 0.02*ones(1,3), 0.035, 0.01, 0.05, 0.05, 0.3, 0.02,...
    0.03, 0.2, 2e-4, 4e-4, 0.03, 0.25]';

% compile dispersions into cell array
param_disp = cell(4,1);
param_disp{1} = [del_e_1, tau_1, alpha_1];
param_disp{2} = [del_e_2, tau_2, alpha_2];
param_disp{3} = [del_e_3, tau_3, alpha_3];
param_disp{4} = [del_e_4, tau_4, alpha_4];

%% alternate model for wet skin
% ref: Raicu et al., Physics in Med & Biol, 2000

% permittivities are e_r and thereby unitless (e = e_0*e_r)
del = 10600; % dielectric increment (unitless)
fc = 0.76e6; % characteristic frequency (Hz)
a = 0.25; % exponent for alpha dispersion
b = 0.076; % exponent for beta dispersion
c = 1; % exponent for gamma dispersion
kl = 2e-3; % conductivity at low frequencies / DC (S/m)
e_h = 61; % permittivity at high frequencies (unitless)



%% select tissue and run model

if(tiss == 15) % Raicu Model (only for wet skin)
    
    e_hat = e_h + del ./ ((1i * f / fc).^a + (1i * f / fc).^(1-b)).^c +...
        kl ./ (1i * w * e_o);    
    
else % Gabriel Model
    
    e_hat = e_inf(tiss) + sig_i(tiss) / 1i / e_o ./ w;
    
    for k = 1:4
        tmp = param_disp{k}(tiss,:);
        del = tmp(1);
        tau = tmp(2);
        a = tmp(3);
        e_hat = e_hat + del ./ (1 + (1i*w*tau).^(1-a));
    end    
    
end

% convert from complex permittivity to real values
% general form: e_hat = e' - j*e''
% e' = e_o * e_r, real part
% e'' = negative of imag part
% Cole-Cole formula normalizes e_hat by e_o => unitless
% e' = real(e_hat) * e_o
% e'' = sig / w / e_o
% e'' = -1 * imag(e_hat) * w * e_o
s = -1 * e_o * imag(e_hat) .* w;
e = e_o * real(e_hat);


