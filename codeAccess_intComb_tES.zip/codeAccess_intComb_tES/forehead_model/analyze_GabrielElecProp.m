%% evaluate Gabriel et al. (1996) electrical properties
% Author: Bryan Howell, PhD
% Created: 11/16/2020
% Short description:
% Assess the accuracy of transcribing models.
% Assess whether permittivities can be ignored for freq. range of interest

%% Tissues to analyze
% format: layer => description: model name and ID
% 1. dermis => wet skin: skin2 at ID = 15
% 2. subdermis => infiltrated fat: fat1 at ID = 6
% 3. muscle: "" at ID = 13
% 4. tendon: "" at ID = 17
% 5. skulll => cortical bone: bone2 at ID = 3
% 6. brain => grey matter: brain1 at ID = 4

% tissues to analyze
tissName = {'skin (wet)', 'fat', 'muscle', 'tendon', 'skull', 'brain (grey)'};
tissID = [15, 6, 13, 17, 3, 4];
numTiss = length(tissID);

% frequencies at which to evaluate
f = 10.^(0:0.1:11); % [Hz]
w = 2 * pi * f;
numFreq = length(f);

% compile (sig(f), eps(f)) for each tissue
S = zeros(numTiss, numFreq); % each row: sig vs. f
E = zeros(numTiss, numFreq); % each row: eps vs. f
for k = 1:numTiss
    [tmp1, tmp2] = calc_GabrielElecProp(f, tissID(k));
    S(k,:) = tmp1;
    E(k,:) = tmp2;
end

%% Evaluate correct transcription

% plot domain and ranges
xRange = [f(1), f(end)];
yRange = [1e-3, 1e6; 1e-3, 1e8; 1e-2, 1e8; 1e-1, 1e8; 1e-3, 1e5; 1e-2, 1e8];

for k = 1:numTiss
    figure;
    hold on;
    plot(f, E(k,:)/e_o, 'k', 'LineWidth', 3);
    plot(f, S(k,:), 'b', 'LineWidth', 3);
    hold off;
    title(tissName{k});
    xlabel('frequency (Hz)');
    ylabel('epsr + sig (S/m)');
    n = (log(yRange(k,1)) / log(10)):1:(log(yRange(k,2)) / log(10));
    set(gca, 'xscale', 'log', 'yscale', 'log', ...
        'xTick', 10.^(1:11), 'yTick', 10.^n);
    axis square;
    xlim(xRange);
    ylim(yRange(k,:));
end

%% Evaluate error in ignoring eps

i1 = 1;
[~, i100] = min(abs(f - 100));
[~, i1k] = min(abs(f - 1e3));
[~, i10k] = min(abs(f - 10e3));

iEval = [i1, i100, i1k, i10k];
numEval = length(iEval);
LM = zeros(numTiss, numEval); % lossless media or not?
for k = 1:numEval
    % represent complex permittivity as phasor
    pVec = E(:,iEval(k)) + 1i* S(:,iEval(k)) / w(iEval(k));
    LM(:,k) = imag(pVec) ./ abs(pVec);
end


