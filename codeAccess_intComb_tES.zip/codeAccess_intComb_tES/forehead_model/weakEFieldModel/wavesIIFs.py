import numpy as np
import numba

''' 
Author: Bryan Howell, Ph.D.
Created: 08/01/2019
This class constructs sinusoidal and rectangular waveforms'''

def rectPulse(amp=0, pw=0, tDelay=0, t=None):
    '''Constructs a rectangular pulse

    Parameters:
    :amp:  amplitude of interference waveform (unitless)
    :pw: pulse width (ms)
    :tDelay: time delay (s)
    :t:     time vector (s)

    Returns:
    :rectWave: rectangular waveform (one pulse, unitless)
    '''
    # time vector
    numPts = len(t)

    # construct unit waveform
    rectWave = np.zeros((numPts,), dtype=np.float64)
    dummyWave = amp * np.ones((numPts,), dtype=np.float64)
    pulseIndices = (t > tDelay) & (t <= (tDelay+pw*1e-3))
    rectWave[pulseIndices] = dummyWave[pulseIndices]
    return rectWave
    
def inf2Wave(amp=1, relStrBase=1, fBase=1e3, fBeat=10, tDelay=0, t=None):
    '''Constructs an interference wave from two sinusoidal waveforms
    - one waveform is the base waveform
    - the other is the modulating waveform introducing the beat frequency

    Parameters:
    :amp:  amplitude of interference waveform (unitless)
    :relStrBase: ABase / ABeat, where As are respect. max. amplitudes of waves (unitless)
    :fBase: base frequency (Hz)
    :fBeat: beat/interference frequency (Hz) 
    :tDelay: time delay (s)
    :t:     time vector (s)

    Returns:
    :infWave: interference wave (unitless)
    '''
    # time vector
    numPts = len(t)

    # construct unit waveform
    y1 = np.sin(2 * np.pi * fBase * (t- tDelay))
    y2 = np.sin(2 * np.pi * (fBase + fBeat) * (t - tDelay))
    ySum = amp * (relStrBase * y1 + y2) / (1 + relStrBase) 
    intWave = np.zeros((numPts,), dtype=np.float64)
    getIndices = (t > tDelay)
    intWave[getIndices] = ySum[getIndices]
    return intWave


