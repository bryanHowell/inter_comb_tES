%% forehead tES model
% Author: Bryan Howell, Ph.D.
% Created: 11/12/2020
%
% Short description:
% Eight-domain spherical model of tES 
% - parameterized to emulate orbitral (anterior) forehead
% Two regions
% 1. sponge (circular arc): h = 9.5 mm
% 2. brain (circle): r = r_head - sum(h_layers)
%
% Six layers
% 1. dermis (+epidermis): h = 1.2 mm
% 2. subdermis /fat: h = 1 mm
% 3. muscle: h = 2 mm
% 4. tendon: h = 0.6 mm
% 5. skull / cranium: h = 7.7 mm
% 6. CSF: h = 2.5 mm 
%
% References (hx => heights, sx => sigmas)
% rh: Chopra, Cosmetic Medicine, 2015
% h2-4: Choi, Ultrasound Medicine Bio, 2019
% h5: Shah, Int. J Medical Sciences, 2018
% h6: Vatta et al., Compt Intell and Neurosci, 2010
%
% sigSpong: Sauerheber and Heingz, Chemical Sciences J, 2015
% (also Veerman, Energies, 2020)
% sig1-5: Gabriel et al. (Part III), Physics and Med & Biology, 1996
% sig6: Baumann et al., IEEE TBME, 1997

clear;
clc;

%% user input

% % stimulation parameters
% fVal = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1e3, 2e3, 5e3, 1e4];
% Zhead = zeros(size(fVal));
% Ebrain = zeros(size(fVal));
% 
% for ff = 1:length(fVal)
    
fStim = 1e3;%fVal(ff);

%% setup COMSOL model

workDir = pwd;

% import libraries
import com.comsol.model.*
import com.comsol.model.util.*

model=ModelUtil.create('Model');
model.modelPath(workDir);
model.modelNode.create('comp1');
model.geom.create('geom1',2); % # dimensions
model.geom('geom1').axisymmetric(true); % axisymmetric
model.modelNode('comp1').sorder('cubic'); % shape fxn order

model.mesh.create('mesh1','geom1'); % mesh object 
model.physics.create('ec','ConductiveMedia','geom1');

model.study.create('std1');
% model.study('std1').create('stat', 'Stationary'); % electrostatic
% model.study('std1').feature('stat').activate('ec', true);
model.study('std1').create('freq', 'Frequency'); % freq. dependent
model.study('std1').feature('freq').activate('ec', true);
model.geom('geom1').lengthUnit('mm'); % length scale mm

%% model setup (parameters)
% layers: skin (1), fat (2), muscle (3), tendon (4), bone (5), CSF (6),
% brain (7)

% constants
e_o = 8.85e-12; % permittivity of free space [F/m]

% head parameters
% average circumference of human head is 56 cm
d_head = 560/pi; % [mm]

% sponge parameters
in2mm = 25.4; % 25.4 mm in 1"
d_elec = 3*in2mm; % diameter of tES electrode [mm]
h_sponge = 9.5; % wet sponge (3/8 in => 9.5 mm)
sig_sponge = 1.5; % same as CSF
eps_sponge = 1; % relative permittivity (unitless)

% layer parameters
% 1. dermis => wet skin: skin2 at ID = 15
% 2. subdermis => infiltrated fat: fat1 at ID = 6
% 3. muscle: "" at ID = 13
% 4. tendon: "" at ID = 17
% 5. skulll => cortical bone: bone2 at ID = 3
% 6. CSF: constant
% 7. brain => grey matter: brain1 at ID = 4
h_layers = [1.2, 1, 2, 0.6, 7.7, 2.5]; % thickness [mm]
hTotal = sum(h_layers); % total thickness
numLayers = length(h_layers);
tissID = [15, 6, 13, 17, 3, -1]; % IDs from Gabriel model
sig_layers = zeros(1, numLayers);
eps_layers = zeros(1, numLayers); 
for k = 1:numLayers
    
    if(tissID(k) < 0) % CSF
        s = 1.5;
        e = e_o;
    else
        [s, e] = calc_GabrielElecProp(fStim, tissID(k));
    end
    
    sig_layers(k) = s;
    eps_layers(k) = e / e_o;
    
end

% brain parameters
[sig_brain, eps_brain] = calc_GabrielElecProp(fStim, 4);
eps_brain = eps_brain / e_o;

%% GEOMETRY

% head
model.geom('geom1').create('c0', 'Circle');
model.geom('geom1').feature('c0').set('r', d_head/2);

% layers of spherical shells
h_buildup = cumsum(h_layers);
for k = 1:numLayers
    
    bName = ['c', num2str(k)];
    model.geom('geom1').create(bName, 'Circle');
    model.geom('geom1').feature(bName).set('r', d_head/2 - h_buildup(k));
    
end

% sponges (2 electrodes)
thElec = round( 360 * d_elec / (pi * d_head) );
% first sponge
model.geom('geom1').create('c7', 'Circle');
model.geom('geom1').feature('c7').set('r', d_head/2 + h_sponge);
model.geom('geom1').feature('c7').set('angle', thElec);
model.geom('geom1').feature('c7').set('rot', 90 - thElec/2);
model.geom('geom1').create('c8', 'Circle');
model.geom('geom1').feature('c8').set('r', d_head/2);
model.geom('geom1').feature('c8').set('angle', thElec);
model.geom('geom1').feature('c8').set('rot', 90 - thElec/2);
model.geom('geom1').create('sponge1', 'Difference');
model.geom('geom1').feature('sponge1').selection('input').set({'c7'});
model.geom('geom1').feature('sponge1').selection('input2').set({'c8'});
% second sponge
model.geom('geom1').create('sponge2', 'Rotate');
model.geom('geom1').feature('sponge2').set('rot', 180);
model.geom('geom1').feature('sponge2').set('keep', 'on');
model.geom('geom1').feature('sponge2').selection('input').set({'sponge1'});

% build geometries
model.geom('geom1').run;

% figure;
% mphgeom(model, 'geom1', 'facealpha', 0.2);
% axis square;

%% MATERIALS
% set propertiers of 7 domains: sponge + 6 layers

domName = {'sponge', 'skin_wet', 'fat', 'muscle', 'tendon', 'skull', 'CSF', 'brain'};
numDom = length(domName);
domID = {[1, 9], 2, 3, 4, 5, 6, 7, 8};
domSig = [sig_sponge, sig_layers, sig_brain];
domEpsr = [eps_sponge, eps_layers, eps_brain];

for k = 1:numDom
    
    % setup materials
    matName = ['mat', num2str(k)];
    model.material.create(matName, 'Common', 'comp1');    
    model.material(matName).label(domName{k});
    model.material(matName).selection.set(domID{k});
    model.material(matName).propertyGroup('def').set('electricconductivity', domSig(k));
    model.material(matName).propertyGroup('def').set('relpermittivity', 0*1 + domEpsr(k));
    
end

%% BOUNDARY CONDITIONS

% reference for bounding box
% dx = 1; % delta move for bounding boxes
% c1 = [0, h_sponge]';
% c2 = [d_elec/2, h_sponge]';
% bndIn = mphselectbox(model, 'geom1', [c1-dx, c2+dx], 'boundary');

% boundaries (hard code for now)
bndIn = 33;
bndOut = 18;

% top electrode
model.physics('ec').feature.create('fp1', 'FloatingPotential', 1);
model.physics('ec').feature('fp1').selection.set(bndIn);
model.physics('ec').feature('fp1').set('I0', '1e-3');

% bottom electrode
model.physics('ec').feature.create('elec','ElectricPotential', 1);
model.physics('ec').feature('elec').selection.set(bndOut);
model.physics('ec').feature('elec').set('V0', 0);

%% MESH

model.mesh('mesh1').create('ftri1','FreeTri');
model.mesh('mesh1').feature('size').set('hauto',3);
model.mesh('mesh1').run;

model.mesh('mesh1').stat.selection.geom('geom1',2);
model.mesh('mesh1').stat.selection.set(1:3);
mstat_all=mphmeshstats(model,'mesh1');
mstat.numele_total=mstat_all.numelem(2);

%% SOLVE

% model.sol.create('sol1');
% model.sol('sol1').study('std1');
% 
% model.study('std1').feature('stat').set('notlistsolnum',1);
% model.study('std1').feature('stat').set('notsolnum','1');
% model.study('std1').feature('stat').set('listsolnum',1);
% model.study('std1').feature('stat').set('solnum','1');
% 
% model.sol('sol1').create('st1', 'StudyStep');
% model.sol('sol1').feature('st1').set('study','std1');
% model.sol('sol1').feature('st1').set('studystep','stat');
% model.sol('sol1').create('v1', 'Variables');
% model.sol('sol1').feature('v1').set('control','stat');
% model.sol('sol1').create('s1', 'Stationary');
% model.sol('sol1').feature('s1').create('fc1','FullyCoupled');
% model.sol('sol1').feature('s1').feature('fc1').set('linsolver','dDef');
% model.sol('sol1').feature('s1').feature.remove('fcDef');
% model.sol('sol1').attach('std1');
% model.sol('sol1').runAll;

model.sol.create('sol1');
model.sol('sol1').study('std1');

model.study('std1').feature('freq').set('notlistsolnum', 1);
model.study('std1').feature('freq').set('notsolnum', '1');
model.study('std1').feature('freq').set('listsolnum', 1);
model.study('std1').feature('freq').set('solnum', '1');
model.study('std1').feature('freq').set('plist', fStim);

model.sol('sol1').create('st1', 'StudyStep');
model.sol('sol1').feature('st1').set('study', 'std1');
model.sol('sol1').feature('st1').set('studystep', 'freq');
model.sol('sol1').create('v1', 'Variables');
model.sol('sol1').feature('v1').set('control', 'freq');
model.sol('sol1').create('s1', 'Stationary');
model.sol('sol1').feature('s1').create('p1', 'Parametric');
model.sol('sol1').feature('s1').feature.remove('pDef');
model.sol('sol1').feature('s1').feature('p1').set('pname', {'freq'});
model.sol('sol1').feature('s1').feature('p1').set('plistarr', {});
model.sol('sol1').feature('s1').feature('p1').set('punit', {'Hz'});
model.sol('sol1').feature('s1').feature('p1').set('pcontinuationmode', 'no');
model.sol('sol1').feature('s1').feature('p1').set('preusesol', 'auto');
model.sol('sol1').feature('s1').feature('p1').set('plot', 'off');
model.sol('sol1').feature('s1').feature('p1').set('plotgroup', 'Default');
model.sol('sol1').feature('s1').feature('p1').set('probesel', 'all');
model.sol('sol1').feature('s1').feature('p1').set('probes', {});
model.sol('sol1').feature('s1').feature('p1').set('control', 'freq');
model.sol('sol1').feature('s1').set('control', 'freq');
model.sol('sol1').feature('s1').create('fc1', 'FullyCoupled');
model.sol('sol1').feature('s1').feature('fc1').set('linsolver', 'dDef');
model.sol('sol1').feature('s1').feature.remove('fcDef');
model.sol('sol1').attach('std1');
model.sol('sol1').runAll;

%% PROCESS

rad = d_head/2 - (h_buildup(1) + h_buildup(2))/2;
cd('axonCoord/');
a = load('arcLengths_MRGaxon_D10um_L150mm.txt');
cd(workDir);
ph1 = a(1) * 360 / (2 * pi * rad);
ph2 = a(end) * 360 / (2 * pi * rad);
delph = (a(9)-a(1)) * 360 / (2 * pi * rad);
ph = ph1:delph:ph2;
xAx = rad*sind(ph)*cosd(0);
yAx = rad*sind(ph)*sind(0);
zAx = rad*cosd(ph);
rAx = sqrt(xAx.^2 + yAx.^2);

phiAx = mphinterp(model, 'V', 'coord', [rAx; zAx]);
Z = mphinterp(model, 'V', 'coord', [0; 91]) / 1e-3;
zProbe = d_head/2-sum(h_layers)-1; % 1 mm below CSF (below skull)
E = mphinterp(model, 'ec.normE', 'coord', [0; zProbe]);

xSub = a(1:8:end);
ySub = phiAx;

iKeep = xSub < 125;
xTmp = xSub(iKeep);
xSamp = [xTmp, xSub(end)];
yTmp = ySub(iKeep);
ySamp = [yTmp, 0.99 * yTmp(end)];

phiTest = csaps(xSamp, ySamp, 1, xSub);
phiNew = csaps(xSamp, ySamp, 1, a);

sd1 = -1*1e3*[diff(ySub(1:2)), diff(ySub,2), diff(ySub(end-1:end))];
sd2 = -1*1e3*[diff(phiTest(1:2)), diff(phiTest,2), diff(phiTest(end-1:end))];

figure;
subplot(2,1,1);
hold on;
plot(-phiAx, 'k');
plot(-phiTest, 'r');
hold off;
subplot(2,1,2);
hold on;
plot(sd1, 'k');
plot(sd2, 'r');
hold off;

M = [zeros(length(phiNew),1), phiNew'];
% dlmwrite('phiDisk_z1p7mm_D6um_L150mm.txt', M, 'delimiter', ' ');


% Zhead(ff) = Z;
% Ebrain(ff) = E;
% 
% ff
% fVal(ff)
% 
% end


% 
% jUnit = mphint2(model,'ec.normJ','line','selection', bndIn); % [A/m]
% iUnit = jUnit * pi * (d_elec * 1e-3); % [A]
% Z = 1 / iUnit;

% M = [ones(length(phiAx),1), phiAx'];
% dlmwrite('test_3.txt',M);
