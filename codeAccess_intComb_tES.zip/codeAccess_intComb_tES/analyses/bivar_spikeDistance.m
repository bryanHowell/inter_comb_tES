function [S] = bivar_spikeDistance(t, x, y)
%% Calculates time-scale independent synchrony of two spike trains.
% Author: Bryan Howell, PhD
% Created: 12/01/2020
%
% INPUTS:
% t, time vector (s)
% x, spike times of 1st population
% y, spike times of 2nd population
%
% OUTPUT:
% S, instantaneous dissimilarity
%
% References:
% Algorithm by Kruez et al., J Neurophys, 2013
% Link: scholarpedia.org/article/SPIKE-distance (algorithm summary)


%% time parameters

dt = diff(t(1:2));
T = t(end);
nt = length(t);
numPrec = round(log(1/dt) / log(10));

%% pre-process spike times

% auxiliary spikes at ends of time window => mitigate edge effects
xPre = [dt, round(sort(x), numPrec), T-dt];
yPre = [dt, round(sort(y), numPrec), T-dt];

% remove spikes that are below time resolution
delx = diff([0, xPre]);
dely = diff([0, yPre]);
keepx = delx / dt >= 1 & xPre <= T & xPre > 0;
keepy = dely / dt >= 1 & yPre <= T & yPre > 0;
x = xPre(keepx);
y = yPre(keepy);
nx = length(x);
ny = length(y);

%% calculate time intervals between spikes

% number of time intervals between spikes
delx = diff(x);
dely = diff(y);
int_xisi = round([x(1), delx, T-x(end) + dt] / dt);
int_yisi = round([y(1), dely, T-y(end) + dt] / dt);
cumint_xisi = [0, cumsum(int_xisi)];
cumint_yisi = [0, cumsum(int_yisi)];

%% previous and following spikes at each time point
% three piecewise constants:
% - three values at each time instant => piecewise constant fxns
% - three fxns per neuron / spike train
% - two spike trains for calculation

% neuron 1
tP_x = zeros(size(t));
tF_x = T * ones(size(t));
for k = 1:nx    
    ap = cumint_xisi(k+1) + 1;
    bp = cumint_xisi(k+2);
    tP_x(ap:bp) = x(k);
    af = cumint_xisi(k) + 1;
    bf = cumint_xisi(k+1);
    tF_x(af:bf) = x(k);    
end
isi_x = tF_x - tP_x;

% neuron 2
tP_y = zeros(size(t));
tF_y = T * ones(size(t));
for k = 1:ny    
    ap = cumint_yisi(k+1) + 1;
    bp = cumint_yisi(k+2);
    tP_y(ap:bp) = y(k);
    af = cumint_yisi(k) + 1;
    bf = cumint_yisi(k+1);
    tF_y(af:bf) = y(k);    
end
isi_y = tF_y - tP_y;

%% temporal weighting based on four corner spikes
% - two corner spikes are previous and following for spike set x
% - two corner spikes are previous and following for spike set y

% nearest distance to other spike for four above fxns
% - tpx and tfx distance to y spikes
% - tpy and tfy distance to x spikes
delt_Pxy = min(abs(ones(ny,1) * tP_x - y' * ones(1,nt)), [], 1);
delt_Fxy = min(abs(ones(ny,1) * tF_x - y' * ones(1,nt)), [], 1);
delt_Pyx = min(abs(ones(nx,1) * tP_y - x' * ones(1,nt)), [], 1);
delt_Fyx = min(abs(ones(nx,1) * tF_y - x' * ones(1,nt)), [], 1);

% define relative time scales
sP_x = t - tP_x;
sF_x = tF_x - t;
sP_y = t - tP_y;
sF_y = tF_y - t;

% define local weighting for each spike set
Sx = (delt_Pxy .* sF_x + delt_Fxy .* sP_x) ./ isi_x;
Sy = (delt_Pyx .* sF_y + delt_Fyx .* sP_y) ./ isi_y;

% dissimilarity profile
% S = (Sx .* isi_y + Sy .* isi_x) ./ mean([isi_x ; isi_y].^2, 1) / 2;
S = (Sx .* isi_y + Sy .* isi_x) ./ mean([isi_x ; isi_y], 1).^2 / 2;
S(isnan(S)) = 1; % clean up NaN => one

%% quality control 

% Ds = trapz(t, S) / T;
% figure;
% hold on;
% plot(t, S, 'k');
% plot(x, 1.1*ones(size(x)), 'b.', 'MarkerSize', 30);
% plot(y, 1.2*ones(size(y)), 'r.', 'MarkerSize', 30);
% hold off;
% title(Ds);

