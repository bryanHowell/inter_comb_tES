%% script to test population spike distance
% Author: Bryan Howell, PhD
% Created: 12/02/2020
%
%%  synthetic data

% time vector
dt = 0.01;
tf = 10;
t = 0:dt:tf;
nt = length(t);

% spike times
N = 25;
numSpike = randi([1, 50], 1, N);
iCase = randi([1, 3], 1, N);
X = cell(N, 1);
for k = 1:N
    c = iCase(k);
    switch(c)
        case(1)
            X{k} = t(randn(1,nt) > 2.25);    
        case(2)
            X{k} = tf * rand(1, numSpike(k));            
        case(3)
            X{k} = 0:1:tf;       
        otherwise
    end
    
end

figure;
hold on;
for k = 1:N
    plot(X{k}, k*ones(size(X{k})), 'k.');
end
hold off;
[Sa, Ds, S] = ppln_spikeDistance(t, X, 0.05);
