function [P1, f] = fourier_transform(t, x)
% Calculate the fourier transform of a signal.
% INPUTS:
% x, signal(arbitrary units)
% t, time (s)
%
% OUTPUTS:
% P1, one-sided spectrum / fourier transform
% f, frequencies (Hz)

% time domain parameters
dt = diff(t(1:2));
Fs = 1 / dt; % sampling frequency [Hz]
L = length(t);
% if signal has odd number of samples
if(mod(L,2) ~=  0)
    % add one time point to make it even
    t = [t, t(end) + dt];
    L = L + 1;
end

f = Fs * (0:(L/2))/L;
X = fft(x);
P2 = abs(X / L);
P1 = P2(1:(L/2 + 1));
P1(2:end-1) = 2 * P1(2:end-1);

end

