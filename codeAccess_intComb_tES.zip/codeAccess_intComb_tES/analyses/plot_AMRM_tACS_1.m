%% script for plotting RM/AM-tACS results for placebo
% Author: Bryan Howell, Ph.D.
% Created: 12/01/2020

clear;
clc;

%% path names and files

% directories
workDir = pwd;
dataDir = [workDir,'/results_scalpStim'];
dataDir2 = [workDir, '/results_brainStim_tACS'];

% scalp files
fName_ZHeadFreq = 'impedHead_freq_wetSkin_Gabriel.txt';
fName_axThresh = {'diskStim_axonThreshDiam_tACS_6mm.txt', ...
                  'diskStim_axonThreshDiam_AMtACS_10HzBeat_6mm.txt', ...
                  'diskStim_axonThreshDiam_RMtACS_10HzBeat_6mm.txt'};
fName_axRsp = {'vmAxon_tACS_10Hz_6V_4mA.txt', ...
               'vmAxon_AMtACS_base1kHz_beat10Hz_1p7V_6p5mA.txt', ...
               'vmAxon_RMtACS_base1kHz_beat10Hz_2V_6mA.txt'};

% brain files
fName_EHeadFreq = 'EBrain1mm_freq_wetSkin_Gabriel.txt';
fName_spikeRate = {'spikeRate_tACS_10Hz_vsEMag.txt', ...
                   'spikeRate_AMtACS_base1kHz_beat10Hz_vsEMag.txt', ...
                   'spikeRate_RMtACS_base1kHz_beat10Hz_vsEMag.txt'};
fName_spikeTime = {'spikeTimes_tACS_10Hz_vsEMag.txt', ...
                   'spikeTimes_AMtACS_base1kHz_beat10Hz_vsEMag.txt', ...
                   'spikeTimes_RMtACS_base1kHz_beat10Hz_vsEMag.txt'};

%% read data

numCases = length(fName_axThresh);

% axon thresholds at scalp
axThresh = cell(numCases, 1);
for k = 1:numCases
    axThresh{k} = load([dataDir, '/', fName_axThresh{k}]);
end

% axon responses at scalp
axRsp = cell(numCases, 1);
for k = 1:numCases
    axRsp{k} = load([dataDir, '/', fName_axRsp{k}]);
end

% Z / E vs. frequency
Zfreq = load([dataDir, '/', fName_ZHeadFreq]);
Efreq = load([dataDir2, '/', fName_EHeadFreq]);

% spike rate vs. E strength for tACS, AM-tACS, and RM-tACS
spikeRate = cell(numCases, 1);
for k = 1:numCases
    spikeRate{k} = load([dataDir2, '/', fName_spikeRate{k}]);
end

% spike times vs. E strength for ""
spikeData = cell(numCases, 1);
for k = 1:numCases
    spikeData{k} = load([dataDir2, '/', fName_spikeTime{k}]);    
end

Emag = unique(spikeData{1}(:,1));
numE = length(Emag);

% synchronization for all E values
S_E = zeros(numCases, numE);
T = 10; % 10 s of simulation time
for ii = 1:numCases
    ii
    for jj = 1:numE

        % get rows of data for current E value
        rows_Ek = spikeData{ii}(:,1) == Emag(jj);
        M = spikeData{ii}(rows_Ek, 2:3);

        % hold spikes in a cell array
        X = matrix2cell(M, 1, 2);

        % calculate spike synchronization
        S_E(ii,jj) = ppln_spikeSync(X, T);

    end
end

%% plot colors

% rows 1-3: black (tACS), dark green (AM-tACS), orange (RM-tACS)
clrs = [0, 0, 0; 0, 78, 56; 217, 83, 25] / 255;

%% plot data - scalp response, axon APs

% define waveforms
tAx = 1e-3 * axRsp{1}(:,1); % [ms => s]
tDel = 1e-3; % [ms => s]
uAx = tAx > tDel;
y1 = sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
y2= (0.5 * sin(2 * pi * 1e3 * (tAx - tDel)) + ...
    0.5 * sin(2 * pi * (1e3+10) * (tAx - tDel))) .* uAx;
y3 = abs(sin(2 * pi * 1e3 * (tAx - tDel))) .* sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
y = [y1, y2, y3];
amp = [4, 6.5, 6];

for k = 1:numCases
    
    figure;
    subplot(2, 12, 3:10);
    plot(tAx, axRsp{k}(:,2), 'LineWidth', 3, 'Color', 'k');
    axis tight;
    xlim([0.2, 0.5]);
    subplot(2, 12, 15:22);
    plot(tAx, -amp(k) * y(:,k), 'LineWidth', 3, 'Color', clrs(k,:));
    axis tight;
    xlim([0.2, 0.5]);
    ylim(max(amp) * [-1,1]);

end

%% waveforms and spectra of three cases

fSamp = 1e5; % [Hz]
dt = 1/fSamp;
t = 0:dt:(10 - dt);

y1 = sin(2 * pi * 10 * t);
y2 = 0.5 * sin(2 * pi * 1e3 * t) + 0.5 * sin(2 * pi * (1e3+10) * t);
y3 = abs(sin(2 * pi * 1e3 * t)) .* sin(2 * pi * 10 * t);
[Y1, fSpec] = fourier_transform(t, y1);
Y2 = fourier_transform(t, y2);
Y3 = fourier_transform(t, y3);

y_all = [y1; y2; y3];
Y_all = [Y1; Y2; Y3];
figure;
for ii = 1:numCases
    subplot(2, numCases, ii);
    plot(t, y_all(ii,:), 'LineWidth', 4, 'Color', clrs(ii,:));
    axis square;
    xlim([0, 0.3]);
    subplot(2, numCases, 3+ii);
    plot(fSpec, Y_all(ii,:), 'LineWidth', 3, 'Color', clrs(ii,:));
    set(gca, 'xScale', 'log');
    xlim([fSpec(1), fSpec(end)]);
    axis square;
    ylim([0, 1]);
end

%% equivalent E / Z of AM and RM waveforms

% time and frequency
fMax = 10 * Zfreq(end,1);
dt = 1/fMax;
t = 0:dt:(10 - dt);
L = length(t);
fEquiv = fMax * (0:(L/2))/L;

% E / Z at all sampled discrete frequencies
ZSpec = interp1(Zfreq(:,1),Zfreq(:,2), fEquiv);
ZSpec(isnan(ZSpec) & fEquiv < Zfreq(1,1)) = Zfreq(1,2);
ZSpec(isnan(ZSpec) & fEquiv > Zfreq(end,1)) = Zfreq(end,2);
ESpec = interp1(Efreq(:,1),Efreq(:,2), fEquiv);
ESpec(isnan(ESpec) & fEquiv < Efreq(1,1)) = Efreq(1,2);
ESpec(isnan(ESpec) & fEquiv > Efreq(end,1)) = Efreq(end,2);
% weighting for FT
wZ = 1e3 ./ [ZSpec, fliplr(ZSpec(2:end-1))]; 
wE = [ESpec, fliplr(ESpec(2:end-1))];

% calculate equivalent impedance for three cases (AC, AM-AC, RM-AC)
fBeat = 10;
numFreq = size(Zfreq,1);
Zcases_freq = zeros(numFreq, 3);
Zcases_freq(:,1) = Zfreq(:,2);
Ecases_freq = zeros(numFreq, 3);
Ecases_freq(:,1) = Efreq(:,2);
for k = 1:numFreq
    
    % current frequency
    fBase = Zfreq(k,1);
    
    % AM wave
    yAM = 0.5 * sin(2 * pi * fBase * t) +  0.5 * sin(2 * pi * (fBase + fBeat) * t); 
    YAM = fft(yAM);
    xAM = ifft(wZ .* YAM);
    eAM = ifft(wE .* YAM);
    Zcases_freq(k,2) = 1e3 / max(xAM);
    Ecases_freq(k,2) = max(eAM);
    
    % RM wave
    yRM = abs(sin(2 * pi * fBase * t)) .* sin(2 * pi * fBeat * t);
    YRM = fft(yRM);   
    xRM = ifft(wZ .* YRM);
    eRM = ifft(wE .* YRM);
    Zcases_freq(k,3) = 1e3 / max(xRM);
    Ecases_freq(k,3) = max(eRM);
    
end

%% plot data - scalp response, stimulation thresholds

f = axThresh{1}(:,1);
iZ = find(ismember(Zfreq(:,1), f));

figure;
hold on;
for k = 1:numCases
    plot(f, axThresh{k}(:, 4) ./ Zcases_freq(iZ,k) / 1e-3, ...
        '-', 'LineWidth', 4, 'Color', clrs(k,:));
end
hold off;
xlabel('Base Frequency (Hz)', 'FontSize', 30);
ylabel('I_{th} (mA)', 'FontSize', 30);
axis square;
set(gca, 'FontSize', 30, 'xScale', 'log', 'yScale', 'log', ...
    'xTick', [10, 100, 1e3, 1e4], 'xTickLabel', {'10', '100', '1k', '10k'}, ...
    'yTick', [0.1, 1, 10,100], 'yTickLabel', [0.1, 1, 10,100]);

%% plot data - brain response, spike times and rate

figure;
hold on;
plot([Emag(1), Emag(end)], 0.3 * [1,1], '--', 'LineWidth', 3, 'Color', 0.5*[1,1,1]);
plot([Emag(1), Emag(end)], [1,1], '--', 'LineWidth', 3, 'Color', 0.5*[1,1,1]);
for k = 1:numCases
    plot(Emag, S_E(k,:), '-', 'LineWidth', 4, 'Color', clrs(k,:));
end
hold off;
xlabel('E (V/m)', 'FontSize', 30);
ylabel('Synchronization', 'FontSize', 30);
axis square;
set(gca, 'FontSize', 30);
ylim([0, 1]);

% % spike rate
% [~, numE] = size(spikeRate{1});
% 
% figure;
% hold on;
% for k = 1:numCases
%     h = boxplot(spikeRate{k}, 'positions', 1:21, 'Colors', clrs(k,:),...
%         'Notch', 'off', 'OutlierSize', 7, 'Symbol', '.');
%     set(findobj(gca, 'type', 'line'), 'linew', 3);
%     set(h, 'MarkerSize', 15);
%     ylabel('spikes / s', 'FontSize', 30);
%     set(gca, 'FontSize', 30, 'xTick', (0:5:20)+1, 'xTickLabel', 0:5:20);
%     axis square;
%     axis tight;
%     xlim([0.5, numE+0.5]);
% end
% hold off;

%% plot data - brain response, synchronization

% tACS => 4 mA => 4 V/m => indx 9
% AM-tACS => 6.5 mA => 4.5 V/m => indx 10
% RM-tACS => 6 mA => 5.5 V/m => indx 12
indxE = [9, 10, 12];

% extract spike times at E = 4 V/m
spikes = cell(numCases, 1);
for k =1:numCases
    tmp = spikeData{k}(:,1) == Emag(indxE(k));
    spikes{k} = matrix2cell(spikeData{k}(tmp, 2:3), 1, 2);    
end

% analyze synchronicity and entrainment strength (spike / sec)
fStim = 10;
numTrials = max(length(spikes{1}));
isi_all = cell(numCases, 1);
rad_all = cell(numCases, 1);
for ii = 1:numCases
    
    % accumulate interspike intervals for all spike trains
    isi = [];
    for jj = 1:numTrials
        isi = [isi, diff(spikes{ii}{jj})]; % inter        
    end
    
    ipi_sim1{ii} = isi;
    rad_all{ii} = 2 * pi * mod(isi, 1/fStim) / (1/fStim);
    
end

% synchronicity
for k = 1:numCases
    figure;
    polarhistogram(rad_all{k}, 100, 'Normalization', 'pdf',...
        'FaceColor', clrs(k,:));
    set(gca, 'FontSize', 40, 'LineWidth', 3, 'rtick', (0:25:50)/100);
    rlim([0,0.5]);
end


