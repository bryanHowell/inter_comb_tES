%% script for plotting RM/AM-tACS results for placebo
% Author: Bryan Howell, Ph.D.
% Created: 12/01/2020

clear;
clc;

%% path names and files

% directories
workDir = pwd;
dataDir = [workDir,'/results_scalpStim'];
dataDir2 = [workDir, '/results_brainStim_tACS'];
dataDir3 = [workDir, '/results_brainStim_tPCS'];

% scalp files
fName_ZHeadFreq = 'impedHead_freq_wetSkin_Gabriel.txt';
fName_axThresh = 'diskStim_axonThresh_pwMPBP_10um_6mm.txt';
fName_axRsp = {'vmAxon_tPCS_1msMP_anode_15p3V_10mA.txt', ...
               'vmAxon_tPCS_5msMP_anode_12p2V_8mA.txt', ...
               'vmAxon_tPCS_10msMP_anode_9p1V_6mA.txt'};

% brain files
fName_EHeadFreq = 'EBrain1mm_freq_wetSkin_Gabriel.txt';
fName_vmpw = 'tPCS_pwms_delVmMaxmV.txt';
fName_spikeTime = {'spikeTimes_tACS_10Hz_vsEMag.txt', ...
                   'spikeTimes_tPCS_10Hz_1msMP_EMag.txt', ...
                   'spikeTimes_tPCS_10Hz_5msMP_EMag.txt', ...
                   'spikeTimes_tPCS_10Hz_10msMP_EMag.txt', ...
                   'spikeTimes_tPCS_10Hz_1msBP_EMag.txt', ...
                   'spikeTimes_tPCS_10Hz_5msBP_EMag.txt', ...
                   'spikeTimes_tPCS_10Hz_10msBP_EMag.txt'};
numCases = length(fName_spikeTime);
spikeTimeDirNum = [2, 3 * ones(1, numCases-1)];

%% read data

% axon thresholds at scalp
axThresh = load([dataDir, '/', fName_axThresh]);
pw = axThresh(:,1);
numpw = length(pw);

% axon responses at scalp
axRsp = cell(length(fName_axRsp), 1);
for k = 1:length(fName_axRsp)
    axRsp{k} = load([dataDir, '/', fName_axRsp{k}]);
end

% Z / E vs. frequency
Zfreq = load([dataDir, '/', fName_ZHeadFreq]);
Efreq = load([dataDir2, '/', fName_EHeadFreq]);
vmMax = load([dataDir3, '/', fName_vmpw]);

% spike times vs. E strength for ""
spikeData = cell(numCases, 1);
for k = 1:numCases
    if(spikeTimeDirNum(k) == 2)
        spikeData{k} = load([dataDir2, '/', fName_spikeTime{k}]);   
    else
        spikeData{k} = load([dataDir3, '/', fName_spikeTime{k}]);    
    end
       
end

Emag = unique(spikeData{1}(:,1));
numE = length(Emag);

return

% synchronization for all E values
S_E = zeros(numCases, numE);
T = 10; % 10 s of simulation time
for ii = 1:numCases
    ii
    for jj = 1:numE

        % get rows of data for current E value
        rows_Ek = spikeData{ii}(:,1) == Emag(jj);
        M = spikeData{ii}(rows_Ek, 2:3);

        % hold spikes in a cell array
        X = matrix2cell(M, 1, 2);

        % calculate spike synchronization
        S_E(ii,jj) = ppln_spikeSync(X, T);

    end
end

%% plot colors

% rows 1-3:
% 1 => black => tACS base case (10 Hz)
% 2-4 => monophasic 1, 5, and 10 ms, lighter shade => smaller PW
% 5-7 => biphasic "", ""
rShades3 = [255, 0, 0; 224, 17, 95; 150, 0, 24] / 255;
clrs = [0, 0, 0; rShades3 ; rShades3];
cRust = [178, 34, 34] / 255;

%% plot data - vm max (pt nrn) vs. pulse width

figure;
plot(vmMax(:,1), vmMax(:,2), 'k', 'LineWidth', 3)
xlabel('pulse width (ms)', 'FontSize', 30);
ylabel('max \DeltaV_m (mV)', 'FontSize', 30);
axis square;
axis tight;
ylim([0, 1.05*max(vmMax(:,2))]);
set(gca, 'xScale', 'log', 'FontSize', 30, ...
    'xTick', [0.1, 1, 10, 100, 1e3], 'xTickLabel', [0.1, 1, 10, 100, 1e3]);

%% plot data - rastors of tACS vs. tPCS (MP and BP)

% train frequency and reference pw
fStim = 10;
pwMin = vmMax(1,1)*1e-3; % [ms => s]
ID = [4,7];
numID = length(ID);
pwBase = 10e-3; % [ms => s]
Eref = [6, 6]; % [V/m]

% time vector for simulations [s]
dt = pwMin;
tDel = 0.25;
tf = 10;
t = 0:dt:tf;

% inputs (tACS, tPCS / MP/ 10 ms, tPCS / BP / 10 ms)
yBase = -0.5 * sawtooth(2 * pi * fStim * t) + 0.5;
ckPos = (yBase >= (0.25 - pwBase*fStim/2)) & (yBase < (0.25 + pwBase*fStim/2));
ckNeg = (yBase >= (0.75 - pwBase*fStim/2)) & (yBase < (0.75 + pwBase*fStim/2));
y(1,ckPos) = 1;
y(2,ckPos) = 1;
y(2,ckNeg) = -1;

% highlight synchronization limits +- 30 deg. from expected peak time
tMin = (0.25 + 0.25 / fStim):(1 / fStim):10;
dt30 = (30 / 180 * pi) / 2 / pi / fStim;

figure;
yOff = -7;
yScale = 5;
for k = 1:numID
    
    subplot(1, numID, k);
    hold on;

    for jj = 1:length(tMin)

        xL = tMin(jj) - dt30;
        xR = tMin(jj) + dt30;                

        fill([xL, xR, xR, xL], [-13, -13, 101, 101], 0.85*[1,1,1], ...
            'LineStyle', 'none');
    end

    
    % get spikes at Emag
    rows = spikeData{ID(k)}(:,1) == Eref(k);
    M = spikeData{ID(k)}(rows, 2:3);
        
    plot(M(:,2), M(:,1), 'ko', 'MarkerFaceColor', 'k', 'Color', 'k');
    plot(t, yScale * y(k,:) + yOff, 'k', 'LineWidth', 4, 'Color', clrs(ID(k),:));    
    hold off;
    ylabel('trials', 'FontSize', 30); 
    set(gca, 'FontSize', 30, 'yTick', [1,25:25:100]);
    xlim([5, 5.5]);
    ylim([-13, 101]);
    
end

%% plot data - scalp response, axon APs
% NOTE: pulse train for axon simulations same wave but timed differently

% define 1, 5, and 10 ms pulse trains
tAx = 1e-3 * axRsp{1}(:,1); % [ms => s]
tDel = 1e-3; % [ms => s]
uAx = tAx > tDel;
pw3 = pw([4,6,7]) * 1e-3; % [ms => s]
fTrain = 10; % [Hz]
wave3 = zeros(length(pw3), length(tAx));
amp = [10, 8, 6];

for k = 1:length(pw3)
    numCyc = round(1 / fTrain / pw3(k));
    p = mod((tAx - tDel) .* uAx / pw3(k), numCyc);    
    ckPos = p >= (numCyc/4 - 0.5) & p <= (numCyc/4 + 0.5);
    yBase = zeros(size(p));
    yBase(ckPos) = 1;
    yBase(~ckPos) = 0;
    wave3(k,:) = yBase;  
end

for k = 1:length(pw3)
    
    figure;
    subplot(2, 12, 3:10);
    plot(tAx, axRsp{k}(:,2), 'LineWidth', 3, 'Color', 'k');
    axis tight;
    xlim([0, 0.275]);
    subplot(2, 12, 15:22);
    plot(tAx, amp(k) * wave3(k, :), 'LineWidth', 3, 'Color', clrs(k+1,:));
    axis tight;
    xlim([0, 0.275]);
    ylim(max(amp) * [0,1]);

end

%% waveforms and spectra of three cases

% time - frequency parameters
fSamp = 1e4; % [Hz]
dt = 1/fSamp;
t = 0:dt:(10 - dt);
L = length(t);

% define waveforms
fStim = 10; % 10 [Hz]
TStim = 1 / fStim;
pw = 10e-3; % [ms => s]
yBase = -0.5*sawtooth(2 * pi * fStim * t) + 0.5;
ckPos = (yBase >= (0.75 - pw*fStim/2)) & (yBase < (0.75 + pw*fStim/2));
ckNeg = (yBase >= (0.25 - pw*fStim/2)) & (yBase < (0.25 + pw*fStim/2));
y1 = zeros(size(t));
y1(ckPos) = 1;
y2 = zeros(size(t));
y2(ckPos) = 1;
y2(ckNeg) = -1;

% fourier spectrum
nSpec = 0:(L/2);
fSpec = fSamp * nSpec / L;
Y1 = fourier_transform(t, y1);
Y2 = fourier_transform(t, y2);

y_all = [y1; y2];
Y_all = [Y1; Y2];

dn = pw/dt;

figure;
for ii = 1:2
    subplot(2, 2, ii);
    plot(t, y_all(ii,:), 'LineWidth', 4, 'Color', cRust);
    axis square;
    xlim([0, 0.25]);
    ylim([-1, 1]);
    subplot(2, 2, 2+ii);
    plot(fSpec((dn:ii*dn:end) + 1), Y_all(ii,(dn:ii*dn:end) + 1), ...
         'LineWidth', 3, 'Color', cRust);  
    set(gca, 'xScale', 'log');
    xlim([10, 2e3]);
    axis square;
    ylim([0, 0.4]);
end

%% equivalent E / Z of AM and RM waveforms

% time and frequency
fSamp = 1e5; % [Hz]
dt = 1/fSamp;
t = 0:dt:(10 - dt);
L = length(t);
nSpec = 0:(L/2);
fSpec = fSamp * nSpec / L;

% E / Z at all sampled discrete frequencies
ZSpec = interp1(Zfreq(:,1),Zfreq(:,2), fSpec);
ZSpec(isnan(ZSpec) & fSpec < Zfreq(1,1)) = Zfreq(1,2);
ZSpec(isnan(ZSpec) & fSpec > Zfreq(end,1)) = Zfreq(end,2);
ESpec = interp1(Efreq(:,1),Efreq(:,2), fSpec);
ESpec(isnan(ESpec) & fSpec < Efreq(1,1)) = Efreq(1,2);
ESpec(isnan(ESpec) & fSpec > Efreq(end,1)) = Efreq(end,2);
% weighting for FT
wZ = 1e3 ./ [ZSpec, fliplr(ZSpec(2:end-1))]; 
wE = [ESpec, fliplr(ESpec(2:end-1))];

% calculate equivalent impedance for all pw
Zcases_pw = zeros(numpw, 1);
Ecases_pw = zeros(numpw, 1);
for k = 1:numpw
    
    % define pulse train and spectrum
    yBase = -0.5*sawtooth(2 * pi * fStim * t) + 0.5;
    pwk = pw(k);
    ckPos = (yBase >= (0.75 - pwk*fStim/2)) & (yBase < (0.75 + pwk*fStim/2));
    y = zeros(size(t));
    y(ckPos) = 1; 
    Y = fft(y);
    
    % AM wave
    x = ifft(wZ .* Y);
    e = ifft(wE .* Y);
    Zcases_pw(k) = 1e3 / max(x);
    Ecases_pw(k) = max(e);
 
end

Zcases_pw(1) = median(Zcases_pw); % why is 0.1 ms giving wrong result?

%% plot data - scalp response, stimulation thresholds

%     plot(pw, axThresh{k}(:, 4) ./ Zcases_freq(iZ,k) / 1e-3, ...
%         '-', 'LineWidth', 4, 'Color', clrs(k,:));

lStyle = {'-', '--'};

figure;
hold on;
for k = 2:size(axThresh,2)
    plot(pw, 1e3 * axThresh(:,k) ./ Zcases_pw, lStyle{k-1}, ...
        'LineWidth', 4, 'Color', cRust);
end
% plot([pw(1),pw(end)], 0.44 * [1,1], 'k', 'LineWidth', 3);
hold off;
xlabel('Pulse width (ms)', 'FontSize', 30);
ylabel('I_{th} (mA)', 'FontSize', 30);
axis square;
set(gca, 'FontSize', 30, 'xScale', 'log', ...
    'xTick', pw(1:3:end), 'xTickLabel', pw(1:3:end));

%% plot data - brain response, spike times and rate

figure;
hold on;
plot([Emag(1), Emag(end)], 0.3 * [1,1], '--', 'LineWidth', 3, 'Color', 0.5*[1,1,1]);
plot([Emag(1), Emag(end)], [1,1], '--', 'LineWidth', 3, 'Color', 0.5*[1,1,1]);
for k = 1:numCases
    if(k > 4)
        lStyle = '--';
    else
        lStyle = '-';
    end
    plot(Emag, S_E(k,:), lStyle, 'LineWidth', 4, 'Color', clrs(k,:), 'MarkerSize', 30);
end
hold off;
xlabel('E (V/m)', 'FontSize', 30);
ylabel('Synchronization', 'FontSize', 30);
axis square;
set(gca, 'FontSize', 30);
ylim([0, 1]);

% % spike rate
% [~, numE] = size(spikeRate{1});
% 
% figure;
% hold on;
% for k = 1:numCases
%     h = boxplot(spikeRate{k}, 'positions', 1:21, 'Colors', clrs(k,:),...
%         'Notch', 'off', 'OutlierSize', 7, 'Symbol', '.');
%     set(findobj(gca, 'type', 'line'), 'linew', 3);
%     set(h, 'MarkerSize', 15);
%     ylabel('spikes / s', 'FontSize', 30);
%     set(gca, 'FontSize', 30, 'xTick', (0:5:20)+1, 'xTickLabel', 0:5:20);
%     axis square;
%     axis tight;
%     xlim([0.5, numE+0.5]);
% end
% hold off;

%% plot data - brain response, synchronization

% tACS => 4 mA => 4 V/m => indx 9
% tPCS 1 ms => 10 mA => 10 V/m => 21
% tPCS 5 ms => 8 mA => 8 V/m => 17
% tPCS 10 ms => 6 mA => 6 V/m => 13
indxE = [9, 21, 17, 13, 21, 17, 13];

% extract spike times at E = 4 V/m
spikes = cell(numCases, 1);
for k =1:numCases
    tmp = spikeData{k}(:,1) == Emag(indxE(k));
    spikes{k} = matrix2cell(spikeData{k}(tmp, 2:3), 1, 2);    
end

% analyze synchronicity and entrainment strength (spike / sec)
fStim = 10;
numTrials = max(length(spikes{1}));
isi_all = cell(numCases, 1);
rad_all = cell(numCases, 1);
for ii = 1:numCases
    
    % accumulate interspike intervals for all spike trains
    isi = [];
    for jj = 1:numTrials
        isi = [isi, diff(spikes{ii}{jj})]; % inter        
    end
    
    ipi_sim1{ii} = isi;
    rad_all{ii} = 2 * pi * mod(isi, 1/fStim) / (1/fStim);
    
end

% synchronicity
for k = 1:(numCases+1)/2
    figure;
    polarhistogram(rad_all{k}, 100, 'Normalization', 'pdf',...
        'FaceColor', clrs(k,:));
    set(gca, 'FontSize', 40, 'LineWidth', 3, 'rtick', (0:25:50)/100);
    rlim([0,0.5]);
end


