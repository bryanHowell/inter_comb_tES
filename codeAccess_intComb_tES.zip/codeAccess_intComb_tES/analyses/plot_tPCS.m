%% script for plotting tPCS results
% Author: Bryan Howell, Ph.D.
% Created: 11/03/2020

clear;
clc;

%% file names

workDir = pwd;
dataDir = [workDir,'/results_tPCS'];

pol = 'anode'; % {anode, cathode}

expFile = 'ptNeuron_endogAnodeCathod_4Vpm.txt';
ctrlFile = {'spikes_100PtNrns_noStim.txt', ...
            'spikes_100PtNrns_tDCS_anode3Vpm.txt', ...
            'spikes_100PtNrns_tDCS_cathode3Vpm.txt'};        
fName = {['spikesVfreq_100PtNrns_',pol,'_3Vpm_duty0p1.txt'], ...
         ['spikesVfreq_100PtNrns_',pol,'_3Vpm_duty0p25.txt'], ...
         ['spikesVfreq_100PtNrns_',pol,'_3Vpm_duty0p5.txt'], ...
         ['spikesVfreq_100PtNrns_',pol,'_3Vpm_duty0p75.txt'], ...
         ['spikesVfreq_100PtNrns_',pol,'_3Vpm_duty0p9.txt']};
numCtrl = length(ctrlFile);
numFiles = length(fName);

%% read and collate data

% example data shows one time series for no stim, tDCS+, and tDCS-
expData = load([dataDir, '/', expFile]);


% control data shows spike rate distribution for example data
ctrlData = cell(numCtrl, 1);
for k =1:numCtrl
    ctrlData{k} = load([dataDir, '/', ctrlFile{k}]); 
end

ctrlTrials = unique(ctrlData{1}(:,1));
numCtrlTrials = length(ctrlTrials);
F_ctrl = zeros(numCtrl, numCtrlTrials);
for ii = 1:numCtrl
    for jj = 1:numCtrlTrials
        F_ctrl(ii,jj) = sum(ctrlData{ii}(:,1)==jj) / 10;
    end
end

% spike data for pulsed tDCS simulations
spikeData = cell(numFiles, 1);
for k = 1:numFiles
    spikeData{k} = load([dataDir, '/', fName{k}]);
end

% frequency / trial information
fVal = unique(spikeData{1}(:,1));
trials = unique(spikeData{1}(:,2));
numFreq = length(fVal);
numTrials = length(trials);

% calculate spike rate per trial per frequency
F_data = cell(numFiles, 1);
for k = 1:numFiles
    
    F_data{k} = zeros(numFreq, numTrials);
    
    for ii = 1:numFreq
        for jj = 1:numTrials
            F_data{k}(ii,jj) = sum(spikeData{k}(:,1)==fVal(ii) ...
                & spikeData{k}(:,2)==trials(jj)) / 10;
        end
    end
    
end

%% statistical testing

% collapse across freq. => pool data only w/ duty cycle
numSamp = numFreq*numTrials;
F_dutyPool = zeros(numFiles, numSamp);
for k = 1:numFiles
    F_dutyPool(k,:) = F_data{k}(:);
end

% unique ways of comparing duty pools
rc_indx = nchoosek(1:numFiles, 2);
num_dutyComb = size(rc_indx,1); % # of comparisons
ks2_duty_p = zeros(num_dutyComb, 1);
for k = 1:num_dutyComb
    a = rc_indx(k,1);
    b = rc_indx(k,2);
    [~, ks2_duty_p(k)] = kstest2(F_dutyPool(a,:), F_dutyPool(b,:));
end
hs2_duty = ks2_duty_p < 0.05 / num_dutyComb;

% compare effect of freq. w/in pools
rc_indx = nchoosek (1:numFreq, 2);
num_freqComb = size(rc_indx,1);
KS2_fPairs = zeros(numFiles, num_freqComb);
% direct comparisons between freq. pairs
for ii = 1:numFiles
    for jj = 1:num_freqComb
        a = rc_indx(jj,1);
        b = rc_indx(jj,2);          
        [~, ~, KS2_fPairs(ii, jj)] = kstest2(F_data{ii}(a,:), F_data{ii}(b,:));        
    end
end
% simulate rand. subsamples btwn freq. pairs
numIter = 1e3;
KS2_randFreq = zeros(numFiles, numIter);
for ii = 1:numFiles
    for jj = 1:numIter
        i1 = datasample(1:numSamp, numTrials);
        i2 = datasample(1:numSamp, numTrials);    
        [~, ~, KS2_randFreq(ii,jj)] = kstest2(F_dutyPool(ii,i1), F_dutyPool(ii,i2));    
    end
end
KS2_randFreq = sort(KS2_randFreq,2);
% find max. contiguous cluster
iMin = round(numIter * 0.025);
iMax = round(numIter * (1-0.025));
ks2Crit_randFreq = KS2_randFreq(:, [iMin,iMax]);
HS2_fPairs = zeros(numFiles, num_freqComb);
for k = 1:numFiles
    HS2_fPairs(k,:) = KS2_fPairs(k,:) <= ks2Crit_randFreq(k,1) | ...
                      KS2_fPairs(k,:) >= ks2Crit_randFreq(k,2);
end
tmp = HS2_fPairs';
indxKeep = find(sum(tmp,2) == numFiles);
[rc_indx(indxKeep,:), tmp(indxKeep,:)]

%% plot tDCS (no, anode, cathode)

figure;
subplot(4, 1, 1:3);
plot(expData(:,1),expData(:,3),'k', 'LineWidth', 3);
axis tight;
xlim([0.25, 9.99]);
ylabel('vm (mV)');
subplot(4, 1, 4);
ckOff = expData(:,2) == 0;
ckC = expData(:,2) < 0;
ckA = expData(:,2) & expData(:,1) < 6.49;
hold on;
plot(expData(ckOff,1),expData(ckOff,2),'k', 'LineWidth', 3);
plot(expData(ckA,1),expData(ckA,2),'r', 'LineWidth', 3);
plot(expData(ckC,1),expData(ckC,2),'b', 'LineWidth', 3);
hold off;
ylabel('E (V/m)');
xlabel('time (s)');
xlim([0.25, 9.99]);


%% plot waveform for PCS analyses

%% plot tPCS vs. duty vs. freq

% plot labeling & axes
fLabel = {'1','2','5','10','20','50','100','200','500','1,000'};
if(strcmp(pol, 'anode'))
    yRange = [0,7];
    clr = [1, 0, 0];
    iCtrl = [1, 2];
else
    yRange = [-0.1,3];    
    clr = [0, 0, 1];
    iCtrl = [1, 3];
end

h = boxplot(F_ctrl(iCtrl,:)', 'positions', 1:2, 'Colors', 'k',...
    'Notch', 'off', 'OutlierSize', 7, 'Symbol', '.', 'Labels', {'off', 'tDCS'});
set(findobj(gca, 'type', 'line'), 'linew', 3);
set(h, 'MarkerSize', 15);
ylabel('spikes / s', 'FontSize', 30);
set(gca, 'FontSize', 30, 'yTick', 0:2:10);
xtickangle(45);
axis square;
xlim([0.5, 2+0.5]);
ylim(yRange);
    
for k = 1:numFiles
    figure;
    h = boxplot(F_data{k}', 'positions', 1:numFreq, 'Colors', clr,...
        'Notch', 'off', 'OutlierSize', 7, 'Symbol', '.', 'Labels', fLabel);
    set(findobj(gca, 'type', 'line'), 'linew', 3);
    set(h, 'MarkerSize', 15);
    ylabel('spikes / s', 'FontSize', 30);
    set(gca, 'FontSize', 30, 'yTick', 0:2:10);
    xtickangle(45);
    axis square;
    xlim([0.5, numFreq+0.5]);
    ylim(yRange);
end
