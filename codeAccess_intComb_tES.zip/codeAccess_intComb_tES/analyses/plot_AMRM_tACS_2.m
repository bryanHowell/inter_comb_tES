%% script for plotting AM/RM-tACS results
% Author: Bryan Howell, Ph.D.
% Created: 11/03/2020

%% file names

workDir = pwd;
dataDir = [workDir,'/results_brainStim_tACS'];

fName_sim1 = {'spikes_100PtNrns_noStim.txt', ...
              'spikes_100PtNrns_tACS_4Vpm_10Hz.txt', ...
              'spikes_100PtNrns_AM-tACS_4Vpm_10HzMod290Hz.txt', ...
              'spikes_100PtNrns_AM-tACS_4Vpm_10HzMod1kHz.txt', ...
              'spikes_100PtNrns_RM-tACS_4Vpm_10HzMod1kHz.txt', ...
              'spikes_100PtNrns_AM-tACS_8Vpm_10HzMod290Hz.txt', ...
              'spikes_100PtNrns_AM-tACS_8Vpm_10HzMod5kHz.txt', ...
              'spikes_100PtNrns_RM-tACS_8Vpm_10HzMod290Hz.txt'};

%% load data

% colors
% clrs = [191, 191, 191; 0, 0, 0; ... % grey, black
%         138, 154, 91; 0, 78, 56; 217, 83, 25; ... % light green, dark "", orange
%         138, 154, 91; 0, 78, 56; 217, 83, 25] / 255; % (see above)
clrs = [128, 128, 128; 0, 0, 0; 0, 78, 56; 217, 83, 25] / 255;

% read data
numSim1 = length(fName_sim1);
spikes_sim1 = cell(1, numSim1);
for k = 1:numSim1
    spikes_sim1{k} = load([dataDir, '/', fName_sim1{k}]);
end

%% PLOT, rastor of four waveforms and spikes
% (off, tACS, AM-tACS, RM-tACS) => IDs of 1, 2, 4, 5

% common stimulation frequency (i.e., beat freq. for AM/RM waves)
fStim = 10;
fBase = 1e3;

% time vector for simulations [s]
dt = (1/fBase)/20;
tDel = 0.25;
tf = 10;
t = 0:dt:tf;

% inputs
y1 = zeros(size(t));
y2 = sin(2 * pi * fStim * (t - tDel)) .* (t > tDel);
y3 = (0.5 * sin(2 * pi * fBase * (t - tDel)) ...
    + 0.5 * sin(2 * pi * (fBase + fStim) * (t - tDel))) .* (t > tDel);
y4 = sin(2 * pi * fStim * (t - tDel)) .* abs(sin(2 * pi * fBase * (t - tDel))) .* (t > tDel);
y = [y1; y2; y3; y4];

% IDs to analyze
ID = [1, 2];
numID = length(ID);

% highlight synchronization limits +- 30 deg. from expected peak time
tMin = (0.25 + 0.75 / fStim):(1 / fStim):10;
tMin2 = (0.25 + 1 / fStim):(1 / fStim):10;
dt30 = (30 / 180 * pi) / 2 / pi / fStim;

figure;
yOff = -7;
yScale = 5;
for k = 1:numID
    
    subplot(1, numID, k);
    hold on;
    if(k > 1)
        for jj = 1:length(tMin)
            if(k == 3)
                xL = tMin2(jj) - dt30;
                xR = tMin2(jj) + dt30;
            else
                xL = tMin(jj) - dt30;
                xR = tMin(jj) + dt30;                
            end
            fill([xL, xR, xR, xL], [-13, -13, 101, 101], 0.85*[1,1,1], ...
                'LineStyle', 'none');
        end
    end
    plot(spikes_sim1{ID(k)}(:,2), spikes_sim1{ID(k)}(:,1), ...
        'ko', 'MarkerFaceColor', 'k', 'Color', 'k');
    plot(t, yScale * y(k,:) + yOff, 'k', 'LineWidth', 4, 'Color', clrs(k,:));    
    hold off;
    ylabel('trials', 'FontSize', 30); 
    set(gca, 'FontSize', 30, 'yTick', [1,25:25:100]);
    xlim([5, 5.5]);
    ylim([-13, 101]);
    
end


%% PLOT, AM/RM-tACS, synchronization strength

% analyze synchronicity and entrainment strength (spike / sec)

numTrials = max(spikes_sim1{1}(:,1));
rate_sim1 = zeros(numSim1, numTrials);
ipi_sim1 = cell(1, numSim1);
rad_sim1 = cell(1, numSim1);
for k = 1:numSim1
    ipi_sim1{k} = diff(spikes_sim1{k}(:,2));
    rad_sim1{k} = 2 * pi * mod(ipi_sim1{k}, 1/fStim) / (1/fStim);
    for ii = 1:numTrials
        rate_sim1(k,ii) = sum(spikes_sim1{k}(:,1)==ii) / 10;
    end
end

% waveforms
t = 0:1e-5:(tDel+2.5*(1/fStim));
y1 = zeros(size(t));
y2 = sin(2*pi*fStim*(t-tDel));
y3 = 0.5*sin(2*pi*290*(t-tDel)) + 0.5*sin(2*pi*(290+fStim)*(t-tDel));
y4 = 0.5*sin(2*pi*5e3*(t-tDel)) + 0.5*sin(2*pi*(5e3+fStim)*(t-tDel));
y5 = sin(2*pi*fStim*(t-tDel)) .* abs(sin(2*pi*290*(t-tDel)));
y6 = 2*y3;
y7 = 2*y4;
y8 = 2*y5;
yy = [y1; y2; y3; y4; y5; y6; y7; y8];
figure;
hold on;
for k = 1:8
    subplot(4, 2, k);
    plot(t, yy(k,:), 'LineWidth', 3, 'Color', clrs(k,:));   
    axis tight;
    xlim(tDel+[0,2.5/fStim]);
    ylim(2*[-1,1]);
end


% entrainment strength
figure;
h = boxplot(rate_sim1', 'positions', 1:numSim1, 'Colors', 1*[0,0,0],...
    'Notch', 'off', 'OutlierSize', 7, 'Symbol', 'k.');
set(findobj(gca, 'type', 'line'), 'linew', 3);
set(h, 'MarkerSize', 15);
xlabel('case', 'FontSize', 24);
ylabel('spike / s', 'FontSize', 24);
set(gca, 'FontSize', 24, 'yTick', 0:2:10);
axis square;
xlim([0.5, numSim1+0.5]);
ylim([0,10]);
% statistical significance
[ri,ci] = find(triu(ones(numSim1),1));
K2 = zeros(numSim1, numSim1);
hp_kst2 = zeros(length(ri), 2); % col1 = accept/reject, col2 = p-value
for k = 1:length(ri)
    [h, p] = kstest2(rate_sim1(ri(k),:), rate_sim1(ci(k),:));
    if(p < 0.025 / length(ri))
        K2(ri(k),ci(k)) = 1;
    end
end

% synchronicity
for k = 3:numSim1
    figure;
    polarhistogram(rad_sim1{k}, 100, 'Normalization', 'pdf',...
        'FaceColor', clrs(k,:));
    set(gca, 'FontSize', 40, 'LineWidth', 3);
    rlim([0,0.6]);
end


