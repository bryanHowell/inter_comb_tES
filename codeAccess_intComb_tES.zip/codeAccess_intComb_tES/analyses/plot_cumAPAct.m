%% Script for plotting results for block and DC+PC synchronization
% Author: Bryan Howell, PhD
% Created: 12/15/2020
% 
% Short description.
% Plots figure demonstrating decrease in axonal activation w/ increase in
% frequency.

clear;
clc;

%% model globals

% fiber diameter distribution
D_val = [2:6, 8:12];
D_counts = repmat([8, 37, 60, 37, 8], [1,2]);
D_cumCounts = [0, cumsum(D_counts)];
numAx = sum(D_counts);
numDiam = length(D_val);

% head impedance for DC / PC stimulation
ZDC = 1.53; % [kOhm]

% plot colors
% red (tDCS), black (tACS), pink (tPCS), maroon (tDC+PCS)
% clrs = [255, 0, 0; 0, 0, 0; 150, 0, 24; 217, 83, 25] / 255;
clrs = [255, 0, 0; 0, 0, 0; 255, 0, 255; 150, 0, 24] / 255;
cDiam = [0, 128, 255; 64, 64, 64] / 255;

%% file information

workDir = pwd;
projDir = '/home/bryan/Desktop/researchScientist/IIFProject';
dataDir = [projDir, '/project_AMP/analyses/results_scalpStim'];
dataDir3 = [workDir, '/results_brainStim_tPCS'];

% scalp thresholds for activation and block
depthAx = [5, 6, 7];
fName_axRsp = {'diskStim_AP_DC_iAmp_D2to6_8to12.txt', ...
               'diskStim_AP_AC10Hz_iAmp_D2to6_8to12.txt', ...
               'diskStim_AP_PC10Hz10ms_iAmp_D2to6_8to12.txt', ...
               'diskStim_AP_DC3mA_PC10Hz10ms_iAmp_D2to6_8to12.txt'};
numCases = length(fName_axRsp);

%% load data

% axon responses at scalp
axRsp = cell(numCases, 1);
for k = 1:numCases
    axRsp{k} = load([dataDir, '/', fName_axRsp{k}]);
end

iAmp = unique(axRsp{1}(:,1));
numLev = length(iAmp);

% two diam ppln locations
rTheta_dist1 = load([dataDir, '/', 'radThetaDist_samp1.txt']);
rTheta_dist2 = load([dataDir, '/', 'radThetaDist_samp3.txt']); % base case

% coord set 1
rUni_1 = rTheta_dist1(:,1);
thUni_1 = 2 * pi * rTheta_dist1(:,2);
x1 = sqrt(rUni_1) .* cos(thUni_1);
y1 = sqrt(rUni_1) .* sin(thUni_1);
xy_1 = [x1, y1];

% coord set 2
rUni_2 = rTheta_dist2(:,1);
thUni_2 = 2 * pi * rTheta_dist2(:,2);
x2 = sqrt(rUni_2) .* cos(thUni_2);
y2 = sqrt(rUni_2) .* sin(thUni_2);
xy_2 = [x2, y2];

%% plot - four waveforms
% 1. tDCS
% 2. tACS
% 3. tPCS
% 4. tDCS + tPCS

dt = 1e-3;
t = 0:dt:1;
fStim = 10; % [Hz]
pw = 10e-3;

y1 = ones(size(t));
y2 = sin(2 * pi * fStim * t);
tPeak = (0:(1/fStim):(fStim-1)*(1/fStim)) + (1/fStim/4);
y3 = zeros(size(t));
for k = 1:length(tPeak)
    iOn = t >= (tPeak(k) - pw/2) & t < (tPeak(k) + pw/2);
    y3(iOn) = 1;
end
y4 = y1 + y3;
y = [y1; y2; y3; y4];

figure;
m = 4;
n = 3;
pVal = 1:n:m*n;
for k = 1:m
    subplot(m, n, pVal(k));
    plot(t, y(k,:), 'Color', clrs(k,:), 'LineWidth', 4);
    axis tight;
    xlim([0,0.4]);
    if(k > 2)
        ylim([0,2]);
    end
end

%% plot - two diam distributions

% nerve diameter
rNerve = 1.05;
oNerve = [6; 0]; % origin of nerve [mm]

figure;
hold on;
h1 = bar(D_val(1:numDiam/2), D_counts(1:numDiam/2));
h2 = bar(D_val(numDiam/2+1:numDiam), D_counts(numDiam/2+1:numDiam));
set(h1, 'faceColor', cDiam(1,:), 'barWidth', 1, 'lineWidth', 2);
set(h2, 'faceColor', cDiam(2,:), 'barWidth', 1, 'lineWidth', 2);
hold off;
ylabel('count', 'FontSize', 30);
xlabel('fiber diameter (\mum)', 'FontSize', 30);
set(gca, 'FontSize', 30);
axis square;
xlim([min(D_val)-1, max(D_val)+1]);

figure;
hold on;
plot(xy_1(:,1), xy_1(:,2), 'ko', 'MarkerSize', 8, ...
    'MarkerFaceColor', cDiam(1,:), 'MarkerEdge', 'none');   
plot(xy_2(:,1), xy_2(:,2), 'ko', 'MarkerSize', 14, ...
    'MarkerFaceColor', cDiam(2,:), 'MarkerEdge', 'none');  
rectangle('Position', rNerve * [-1, -1, 2, 2], ...
    'Curvature', [1,1], 'LineWidth', 3);
hold off;
axis square;
axis tight;

%% plot - nerve AP count (per s)

% # AP / s / axon
AP_delta = zeros(numLev, numCases);
AP_beta = zeros(numLev, numCases);
ia = 1:(length(D_val)/2);
ib = ((length(D_val)/2)+1):length(D_val);
for k = 1:numCases
    AP_delta(:,k) = axRsp{k}(:,ia+1) * D_counts(ia)' / numAx;
    AP_beta(:,k) = axRsp{k}(:,ib+1) * D_counts(ib)' / numAx;
end

figure;
hold on;
for k = 1:numCases
    plot(iAmp, AP_delta(:,k), '.-', 'Color', clrs(k,:),...
        'MarkerSize', 30, 'LineWidth', 4);
end
hold off;
axis square;
xlabel('current (mA)', 'FontSize', 30);
ylabel('AP rate (Hz)', 'FontSize', 30);
title('A\delta Population', 'FontSize', 30);
set(gca, 'FontSize', 30, 'xTick', [1, 2.5:2.5:10]);
axis tight;
ylim([0, 100]);

figure;
hold on;
for k = 1:numCases
    plot(iAmp, AP_beta(:,k), '.-', 'Color', clrs(k,:),...
        'MarkerSize', 30, 'LineWidth', 4);
end
hold off;
axis square;
xlabel('current (mA)', 'FontSize', 30);
ylabel('AP rate (Hz)', 'FontSize', 30);
title('A\beta Population', 'FontSize', 30);
set(gca, 'FontSize', 30, 'xTick', [1, 2.5:2.5:10]);
axis tight;
ylim([0, 100]);

% AP = (AP_delta + AP_beta) / 2;
% figure;
% hold on;
% for k = 1:numCases
%     plot(iAmp, AP(:,k), '.-', 'Color', clrs(k,:),...
%         'MarkerSize', 30, 'LineWidth', 4);
% end
% hold off;
% axis square;
% xlabel('current (mA)', 'FontSize', 30);
% ylabel('AP rate (Hz)', 'FontSize', 30);
% set(gca, 'FontSize', 30, 'xTick', [1, 2.5:2.5:10]);
% axis tight;
% ylim([0, 100]);

%% plot - example of axonal responses for QAB

% % define 1, 5, and 10 ms pulse trains
% tAx = 1e-3 * axRsp{1}(:,1); % [ms => s]
% tDel = 1e-3; % [ms => s]
% tBuffer = 5e-3; % ""
% uAx = (tAx > tDel) & tAx <= (tAx(end) - tBuffer);
% 
% % DC cases
% figure;
% for k = 1:3
%     subplot(3, 1, k);
%     plot(tAx, axRsp{k}(:,2), 'LineWidth', 3, 'Color', 'k');
%     axis tight;
%     xlim([tDel, tAx(end) - tBuffer]);
% end
% 
% % waveforms for three DC + PC cases
% fTrain = 10; % [Hz]
% pw = 10e-3; % [ms => s]
% indxE = [7, 11, 15];
% numVal = length(indxE);
% wave3 = zeros(numVal, length(tAx));
% pcAmp = Emag(indxE);
% dcAmp = 3;
% for k = 1:numVal
%     
%     numCyc = round(1 / fTrain / pw);
%     p = mod((tAx - tDel) .* uAx / pw, numCyc);    
%     ckPos = p >= (numCyc/4 - 0.5) & p <= (numCyc/4 + 0.5);
%     yBase = zeros(size(p));
%     yBase(ckPos) = pcAmp(k);
%     yBase(~ckPos) = 0;
%     wave3(k,:) = yBase + dcAmp;  
%     
% end
% 
% yMax = max(pcAmp + dcAmp);
% for k = 1:numVal
%     
%     figure;
%     subplot(2, 12, 3:10);
%     plot(tAx, axRsp{k+3}(:,2), 'LineWidth', 3, 'Color', 'k');
%     axis tight;
%     xlim([tDel, tAx(end) - tBuffer]);
%     subplot(2, 12, 15:22);
%     plot(tAx, wave3(k, :), 'LineWidth', 3, 'Color', rShades3(3,:));
%     axis tight;
%     xlim([tDel, tAx(end) - tBuffer]);
%     ylim(yMax * [0,1]);
% 
% end
