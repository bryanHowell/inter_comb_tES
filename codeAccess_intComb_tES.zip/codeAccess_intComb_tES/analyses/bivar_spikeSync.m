function [c_xy] = bivar_spikeSync(x, y, T)
%% Calculates time-scale independent synchrony of two spike trains.
% Author: Bryan Howell, PhD
% Created: 12/01/2020
%
% INPUTS:
% x, spike times of 1st population (s)
% y, spike times of 2nd population (s)
% T, time interval (s)
%
% OUTPUT:
% Cxy, coincidence of x with y (1 x nx)
% - 0, spike i of x not coincident with any spikes j of y
% - 1, spike i of x is coincident with a spike in j of y
% - nx, number of spikes in x
%
% References:
% Algorithm by Kruez et al., J Neurophys, 2015
% Link: scholarpedia.org/article/Measures_of_spike_train_synchrony

%% pre-process spike times

% auxiliary spikes at ends of time window => mitigate edge effects
xTmp = sort(x);
yTmp = sort(y);

% remove spikes that are below time resolution
delx = diff([0, xTmp]);
dely = diff([0, yTmp]);
keepx = delx ~= 0 & xTmp > 0 & xTmp <= T;
keepy = dely ~= 0 & yTmp > 0 & yTmp <= T;
x = xTmp(keepx);
y = yTmp(keepy);
nx = length(x);
ny = length(y);

%% determine if spikes are coincident

% for each spike, calculate isi between previous and following spikes
delt_Px = diff([0, x]);
delt_Fx = diff([x, T]);
delt_Py = diff([0, y]);
delt_Fy = diff([y, T]);

% get smallest isi between neighboring spikes for x and y sets
minISI_x = min([delt_Px; delt_Fx], [], 1);
minISI_y = min([delt_Py; delt_Fy], [], 1);

% for each spike i of x, determine which spike j of y is closest
[min_dt_xy, jMin] = min(abs(ones(ny, 1) * x - y' * ones(1, nx)), [], 1);

% for each spike i of x, 
tau_xy = min([minISI_x ; minISI_y(jMin)], [], 1) / 2;

%% determine if spikes are coincident
% - coincidence based on local spike rate
% - each spike in x is compared to all spikes in y
% - spike i is coincident if min_j(xi - yj) < tau_ij

c_xy =  min_dt_xy < tau_xy;

