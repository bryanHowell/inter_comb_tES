%% Script for assessing block limits
% Author: Bryan Howell, PhD
% Created: 06/03/2021
% Description
% This is a supplemental analysis for determining metrics for when block or
% pseudo-block occur for DC stimuli

%% file information

workDir = pwd;
dataDir = 'block_testCases';

cd(dataDir);
dirInfo = dir;
cd ..;

fileNames = {dirInfo.name};
fileNames = {fileNames(3:end)};
fileNames = fileNames{1};

%% read files
% three scenarios

% 0. reference case (no test stimulation)
% - pseudo block at 1 nA
vmData0 = cell(2, 1);
i0 = [1, 8];
for k = 1:2
    vmData0{k} = load([dataDir, '/', fileNames{i0(k)}]);
end

% 1. subthreshold stimulation
vmData1 = cell(3, 1);
i1 = 2:4;
for k = 1:3
    vmData1{k} = load([dataDir, '/', fileNames{i1(k)}]);
end

% 2. pseudo block
vmData2 = cell(3, 1);
i2 = 5:7;
for k = 1:3
    vmData2{k} = load([dataDir, '/', fileNames{i2(k)}]);
end

% 3. block
vmData3 = cell(3, 1);
i3 = 9:11;
for k = 1:3
    vmData3{k} = load([dataDir, '/', fileNames{i3(k)}]);
end

%% visualize blocking assessment

% rows
% 1 => red for record
% 2 => blue for block
% 3 => teal for test stimulus
c3 = [1, 0, 0; 0 , 0, 1; 0, 0.5,  0.5];
lw = 3;

figure;
for k = 1:3
    kr = 3-k+1;
    subplot(3,3,1+k-1); plot(vmData1{kr}(:,1), vmData1{kr}(:,2), ...
        'k', 'Color', c3(kr,:), 'LineWidth', lw);
    subplot(3,3,4+k-1); plot(vmData2{kr}(:,1), vmData2{kr}(:,2), ...
        'k', 'Color', c3(kr,:), 'LineWidth', lw);
    subplot(3,3,7+k-1); plot(vmData3{kr}(:,1), vmData3{kr}(:,2), ...
        'k', 'Color', c3(kr,:), 'LineWidth', lw);   
    xlabel('time (ms)');
end
subplot(3,3,1); ylabel('subthreshold (0.2 nA)');
subplot(3,3,4); ylabel('pseudoblock (0.6 nA)');
subplot(3,3,7); ylabel('block (1.2 nA)');

figure;
subplot(3,4,2:3);
plot([0,25,25,75,75,100], [0, 0, 1, 1, 0, 0], ...
    'b', 'LineWidth', 3);
ylim([0,1.2]);
ylabel('I_{block} (nA)');

subplot(3,4,6:7); 
hold on;
subplot(3,4,6:7); plot([0,100], -48*[1,1], ...
    'Color', 0.5*[1,1,1], 'LineStyle', '--', 'LineWidth', 2);
plot(vmData0{2}(:,1), vmData0{2}(:,2), 'k', 'LineWidth', 3);
hold off;
ylabel('V_m (mV)');

subplot(3,4,10:11); 
hold on;
plot([0,100], 0.0175*[1,1], ...
    'Color', 0.75*[0.85, 0.325, 0.098], 'LineStyle', '--', 'LineWidth', 2);
plot(vmData0{1}(:,1), vmData0{1}(:,2), ...
    'Color', [0.85, 0.325, 0.098], 'LineWidth', 3);
hold off;
ylim([-0.2,1]);
ylabel('h (nV)');
xlabel('time (ms)');

%% state analysis
% 1. evoke AP with one intracellular stimulus
% 2. add a blocking intracellular stimulus to middle of axon
% 3. record AP activity at the end of the axon

Iblock_val = 0:0.1:1.5;
vm_ss = -[79, 75, 70, 70, 67, 63, 59, 56, 53, 50, 48, 45, 44, 42, 39, 38];
h_ss = [0.62, 0.46, 0.29, 0.28, 0.21, 0.14, 0.08, 0.05, 0.03,...
    0.02, 0.02, 0.013, 0.01, 0.008, 0.006, 0.005];

figure;
subplot(1, 2, 1);
hold on;
plot([0,1.5], -45*[1,1], 'Color', 0.5*[1,1,1], ...
    'LineStyle', '--', 'LineWidth', 2);
plot([0,1.5], -70*[1,1], 'Color', 0.5*[1,1,1], ...
    'LineStyle', '-', 'LineWidth', 2);
plot(Iblock_val, vm_ss, 'k', 'LineWidth', 3);
hold off;
xlabel('I_{block} (nA)', 'FontSize', 30);
ylabel('V_{m, ss} (mV)', 'FontSize', 30);
set(gca, 'FontSize', 24);
axis square;

subplot(1, 2, 2);
hold on;
plot([0,1.5], 0.01*[1,1], 'Color', 0.75*[0.85, 0.325, 0.098], ...
    'LineStyle', '--', 'LineWidth', 2);
plot([0,1.5], 0.28*[1,1], 'Color', 0.75*[0.85, 0.325, 0.098], ...
    'LineStyle', '-', 'LineWidth', 2);
plot(Iblock_val, h_ss, 'Color', [0.85, 0.325, 0.098], 'LineWidth', 3);
hold off;
ylim([-0.2,0.8]);
xlabel('I_{block} (nA)', 'FontSize', 30);
ylabel('h_{ss}', 'FontSize', 30);
set(gca, 'FontSize', 24);
axis square;
