%% Script for plotting disk stimulation results
% Author: Bryan Howell, PhD
% Created: 11/23/2020
% 
% Short description.
% Plots figure demonstrating decrease in axonal activation w/ increase in
% frequency.

clear;
clc;

%% file info.

workDir = pwd;
projDir = '/home/bryan/Desktop/researchScientist/IIFProject';
phiDir = [projDir, '/mrgmodel_v2p1/diskPhi'];
dataDir = [projDir, '/project_AMP/analyses/results_scalpStim'];

phiFile = 'phiDiskRaw_z6mm_D10um_L150mm.txt';
ZFile = 'impedHead_freq_wetSkin_Gabriel.txt';
dAx = [5, 6, 7];
threshFilePre = 'diskStim_axonThreshDiam_tACS_';
vmFiles = {'vmNoR_APInit_50HztACS_10um_6mm.txt', ...
           'vmNoR_Last_50HztACS_10um_6mm.txt'};

%% load data

% example of phi and SD (second difference)
phiPre = load([phiDir, '/', phiFile]);
phiUnit = [flipud(phiPre(1:8:end, 2)); phiPre(1:8:end, 2)];

% head impedance vs. freq
Zhead = load([dataDir, '/', ZFile]);
f = Zhead(:,1);

% voltage thresohlds vs. freq
numFiles = length(dAx);
thData = cell(numFiles, 1);
for jj = 1:numFiles
    thData{jj} = load([dataDir, '/', threshFilePre, num2str(dAx(jj)), 'mm.txt']);
end

% vm(t) for 50 Hz stim at threshold
num_vmFiles = length(vmFiles);
vmData = cell(num_vmFiles, 1);
for k = 1:num_vmFiles
    vmData{k} = load([dataDir, '/', vmFiles{k}]);
end

%% panel, example of 50 Hz stim of axon

% re-define stimulus fron Neuron code
tDel = 1; % time delay before stimulation [ms]
fStim = 50; % frequency of stimulus [Hz]
numCycles = 10; % number of stimulation cycles 
T = 1e3 / fStim * numCycles; % duration of stimulus
t = vmData{1}(:,1);
xStim = sin(2 * pi * 50 * (t - tDel) * 1e-3) .* (t > tDel & t <= (tDel + T));

figure;
hold on;
subplot(3, 1, 1); plot(t, vmData{2}(:,2), 'k', 'LineWidth', 3);
axis tight;
subplot(3, 1, 2); plot(t, vmData{1}(:,2), 'k', 'LineWidth', 3);
axis tight;
subplot(3, 1, 3); plot(t, xStim, 'k', 'LineWidth', 3);
axis tight;
hold off;

%% panel, phi and SD at I = 1 mA

I10 = 1 / Zhead(1,2) * 1e3; % [mA]
VtoI10 = 1 / I10;

figure;
subplot(2, 1, 1);
plot(VtoI10 * phiUnit, 'k', 'LineWidth', 4);
axis tight;
subplot(2, 1, 2);
plot(VtoI10 * diff(phiUnit,2), 'k', 'LineWidth', 4);
axis tight;

%% panel, head impedance vs. frequency

fDec = [10, 100, 1e3, 1e4];
indx_fDec = zeros(size(fDec));
for jj = 1:length(fDec)
    [~, indx_fDec(jj)] = min(abs(f - fDec(jj)));
end

figure;
plot(Zhead(:,1), Zhead(:,2)*1e-3, 'k.-', 'LineWidth', 3, 'MarkerSize', 30);
set(gca, 'xscale', 'log');
xlabel('frequency (Hz)', 'FontSize', 30);
ylabel('Z_{head} (k\Omega)', 'FontSize', 30);
set(gca, 'xTick', [1, 10, 100, 1e3, 1e4], 'xTickLabel', ...
    {'1', '10', '100', '1k', '10k'}, 'FontSize', 24);
axis square;
axis tight;
ylim([0,1.6]);

%% panel, I_th vs. freq

fsub = Zhead(4:end, 1);
Zsub = Zhead(4:end, 2) * 1e-3;
numDiam = size(thData{1}, 2) - 1;
indx_midDiam = round((numDiam + 1)/2);

figure;
hold on;
plot([fsub(1), fsub(end)], 2 *[1,1], '--', 'LineWidth', 3, ...
    'Color', [1, 0, 0]);
plot(fsub, thData{2}(:,1+1) ./ Zsub, 'kd-', 'LineWidth', 2, ...
    'MarkerSize', 12, 'MarkerFaceColor', 'k');
plot(fsub, thData{2}(:,indx_midDiam+1) ./ Zsub, 'ko-', 'LineWidth', 2, ...
    'MarkerSize', 12, 'MarkerFaceColor', 'k');
plot(fsub, thData{2}(:,numDiam+1) ./ Zsub, 'ks-', 'LineWidth', 2, ...
    'MarkerSize', 12, 'MarkerFaceColor', 'k');
hold off;
set(gca, 'xScale', 'log', 'yScale', 'log', ...
    'xTick', [1, 10, 100, 1e3, 1e4], ...
    'xTickLabel', {'1', '10', '100', '1k', '10k'}, 'FontSize', 24, ...
    'yTick', [0.1, 1, 2, 10, 20], 'yTickLabel', [0.1, 1, 2, 10, 20]);
xlabel('frequency (Hz)', 'FontSize', 30);
ylabel('I_{th} (mA)', 'FontSize', 30);
axis square;
axis tight;

%% panel, diameter distribution

D_val = [8, 9, 10, 11, 12];
D_counts = [8, 37, 60, 37, 8];
D_cumCounts = [0, cumsum(D_counts)];
numAx = sum(D_counts);

hBar = bar(D_counts, 1, 'FaceColor', 0.5*[1,1,1]);
xlabel('diameter (\mum)', 'FontSize', 30);
ylabel('count', 'FontSize', 30);
axis square;
set(gca, 'FontSize', 24, 'xTick', 1:5, 'xTickLabel', 8:12);
set(hBar, 'LineWidth', 2);
ylim([0, 1.2*max(D_counts)]);

%% panel, nerve response

% nerve diameter
rNerve = 1.05;
oNerve = [6; 0]; % origin of nerve [mm]

ifreq = 4:13;
Zfreq = Zhead(ifreq, 2) * 1e-3; % [kOhm]
numFreqEval = length(ifreq);

% I threshold vs. fiber diameter vs. depth
% organization of threshold data
% rows 1-10: 10, 20, 50, 100, 200, 500, 1k, 2k, 5k, 10k (frequency)
% cols 1-5: freq, 8, 9, 10, 11, 12 um (fiber diameter)
% depth 1-3: 5, 6, 7 mm (z depth)
Ith_diam = zeros(numFreqEval, numDiam, numFiles);
for kk = 1:numFiles
    Ith_diam(:,:,kk) = thData{kk}(:,2:end) ./ (Zfreq*ones(1, numDiam));
end

% sample uniform dists. of r [0, 1] and theta [0, 2pi)
rTheta_dist = load([dataDir, '/', 'radThetaDist_samp3.txt']);
% rTheta_dist = lhsdesign(numAx, 2);
rUni = rTheta_dist(:,1);
thUni = 2 * pi * rTheta_dist(:,2);
% dlmwrite('radThetaDist_samp3.txt', rTheta_dist);

% uniform point picking in a disk
x = sqrt(rUni) .* cos(thUni);
y = sqrt(rUni) .* sin(thUni);
xy = [x, y];

% distance of each axon
rAx = sqrt(sum((oNerve*ones(1, numAx) + xy').^2, 1))';

% interpolate threshold of each axon
IAx = zeros(numAx, numFreqEval);
for ii = 1:numDiam
    
    ro = D_cumCounts(ii)+1;
    rf = D_cumCounts(ii+1);
    
    for jj = 1:numFreqEval
        yTmp = squeeze(Ith_diam(jj, ii, :));
        IAx(ro:rf, jj) = interp1(dAx', yTmp, rAx(ro:rf));
    end
    
end

% % check if any  points are too close such that two fiber diamters would
% % overlap
% xyPairs = nchoosek(1:numAx, 2);
% xy1 = xy(xyPairs(:,1), :);
% xy2 = xy(xyPairs(:,2), :);
% dxy = sqrt(sum((xy1 - xy2).^2, 2));
% ckGood = ~any(dxy < 12/1e3/2); % would any axons physically overlap

% cross section of active axons in nerve vs. frequency
iFreqPlot = 3:6;
for ii = iFreqPlot
    figure;
    hold on;
    for jj = 1:numDiam

        % get values for given diameter
        ro = D_cumCounts(jj)+1;
        rf = D_cumCounts(jj+1);
        xD = x(ro:rf);
        yD = y(ro:rf);
        ID = IAx(ro:rf, ii);

        % which ones are active
        ckFire = ID <= 1; % use 1 mA stimulation

        % size factor for plotting
        sFac = (D_val(jj)/max(D_val)).^2;

        % plot active and inactive
        plot(xD(ckFire), yD(ckFire), 'ko', 'MarkerSize', 16*sFac, ...
            'MarkerFaceColor', [0, 0.5, 0], 'MarkerEdge', 'none');   
        plot(xD(~ckFire), yD(~ckFire), 'ko', 'MarkerSize', 16*sFac, ...
            'MarkerFaceColor', 0*[1,1,1], ...
            'MarkerEdgeColor', 0*[1,1,1], 'LineWidth', 3);

    end
    rectangle('Position', rNerve * [-1, -1, 2, 2], ...
        'Curvature', [1,1], 'LineWidth', 3);
    hold off;
    axis square;
    axis tight;
end

% percent activation
pa_1mA = 100 * sum(IAx <= 1, 1) / totCounts;
pa_2mA = 100 * sum(IAx <= 2, 1) / totCounts;

% percent activated vs. frequency for set amplitude
fStim = thData{1}(:,1);
figure;
hold on;
plot(fStim, pa_1mA, 'k-', 'LineWidth', 4);
plot(fStim, pa_2mA, 'k--', 'LineWidth', 4);
plot(fStim(iFreqPlot), pa_1mA(iFreqPlot), 'k.', 'MarkerSize', 45);
hold off;
xlabel('frequency (Hz)', 'FontSize', 30);
ylabel('Percent Activated', 'FontSize', 30);
set(gca, 'xScale', 'log', 'FontSize', 24, ...
    'xTick', [10, 100, 1e3, 1e4], 'xTickLabel', {'10', '100', '1k', '10k'});
axis square;
legend('1 mA', '2 mA', 'Location', 'NE');







