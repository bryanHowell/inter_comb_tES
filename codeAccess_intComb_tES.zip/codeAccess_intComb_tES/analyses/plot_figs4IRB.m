%% Figure Panels for IRB (TES Sensory Thresholds)
% Author: Bryan Howell, PhD
% Created: 01/12/2021   
% 
% Short description.
% Plot panels for IRB on Quantifying TES Sensory Thresholds

clear;
clc;

%% PLOT - current regulation

% steady current vs. impedance
t = 0:0.1:15;
% 5 s of steady current at 2.5 kOhm
% 5 s of variable Z from 100 Ohm - 10 kOhm
% 5 s of steady current at 5 kOhm
z = zeros(size(t));
phase1 = t < 5;
z(phase1) = 2.5;
phase2 = t >= 5 & t < 10;
rSamp = rand(1, sum(phase2));
z(phase2) = 0.1 + 9.9 * rSamp;
phase3 = t >= 10;
z(phase3) = 2.5;
I = ones(size(t));
I(phase2) = 1 + 0.01 * (rSamp - 0.5);

figure;
subplot(2,1,1);
plot(t, z, 'k', 'LineWidth', 4);
ylabel('Z (k\Omega)', 'FontSize', 30);
set(gca, 'FontSize', 24, 'xTick', []);
subplot(2,1,2);
plot(t, I, 'k', 'LineWidth', 4);
ylabel('I (mA)', 'FontSize', 30);
ylim([0,2]);
xlabel('time (s)', 'FontSize', 30);
set(gca, 'FontSize', 24);

% abrupt open- and closed-circuits
tOpen = t(phase2);
yOpen = 2.5 * exp((tOpen - tOpen(1)) / 0.1);
Idecay = 1 * exp(-(tOpen - tOpen(1)) / 0.1);
z(phase2) = yOpen;
I2 = ones(size(t));
I2(phase2) = Idecay;
I2(phase3) = (t(phase3) - 10) / 30;

figure;
subplot(2,1,1);
plot(t, z, 'k', 'LineWidth', 4);
ylabel('Z (k\Omega)', 'FontSize', 30);
set(gca, 'FontSize', 24, 'xTick', []);
ylim([0.1,10]);
subplot(2,1,2);
plot(t, I2, 'k', 'LineWidth', 4);
ylabel('I (mA)', 'FontSize', 30);
ylim([0,2]);
xlabel('time (s)', 'FontSize', 30);
set(gca, 'FontSize', 24);

%% PLOT - experimental design

sUnit = [10, 5];
s = [0, cumsum(repmat(sUnit, [1, 4*3]))];
y1 = [1, 1.3, 1.2, 1.4];
yy1 = [y1; 0.75*y1];
y2 = [2.5, 2.5, 3, 3.1];
yy2 = [y2; 0.75*y2];
y = [0, yy1(:)', yy2(:)', zeros(1, 8)];
yC = [0, y1(1), zeros(1,7), y2(1), zeros(1,7), zeros(1, 8)];

ymu1 = mean(y1);
ymu2 = mean(y2);

figure;
subplot(2,1,1);
hold on;
plot([0, 60], ymu1 * [1,1], 'g--', 'LineWidth', 3);
plot([60, 120], ymu2 * [1,1], 'r--', 'LineWidth', 3);
plot(s, y, 'k-', 'LineWidth', 3);
plot(s(2:2:16), y(2:2:16), 'k.', 'MarkerSize', 30);
hold off;
title('active', 'FontSize', 30);
ylabel('current (mA)', 'FontSize', 30);
set(gca, 'FontSize', 30, 'xTick', []);
xlim([0,180]);

subplot(2,1,2);
hold on;
plot(s, yC, 'k-', 'LineWidth', 3);
plot(s(2:2:16), yC(2:2:16), 'k.', 'MarkerSize', 30);
hold off;
title('placebo', 'FontSize', 30);
xlabel('time (s)', 'FontSize', 30);
ylabel('current (mA)', 'FontSize', 30);
set(gca, 'FontSize', 30);
xlim([0,180]);


