%% Script for plotting results for block and DC+PC synchronization
% Author: Bryan Howell, PhD
% Created: 12/15/2020
% 
% Short description.
% Plots figure demonstrating decrease in axonal activation w/ increase in
% frequency.

clear;
clc;

%% model globals

% fiber diameter distribution
D_val = [8, 9, 10, 11, 12];
D_counts = [8, 37, 60, 37, 8];
D_cumCounts = [0, cumsum(D_counts)];
numAx = sum(D_counts);
numDiam = length(D_val);

% head impedance for DC / PC stimulation
ZDC = 1.53; % [kOhm]

% plot colors
rShades3 = [255, 0, 0; 224, 17, 95; 150, 0, 24] / 255;

%% file information

workDir = pwd;
projDir = '/home/bryan/Desktop/researchScientist/IIFProject';
dataDir = [projDir, '/project_AMP/analyses/results_scalpStim'];
dataDir3 = [workDir, '/results_brainStim_tPCS'];

% scalp thresholds for activation and block
depthAx = [5, 6, 7];
threshFilePre = 'diskStim_Q2AThresh_A2BThresh_D8to12by1um_z';
fName_axRsp = {'vmAxon_anode_tDCS_0p78V_0p5mA_D10um_z6mm.txt', ...
               'vmAxon_anode_tDCS_1p53V_1mA_D10um_z6mm.txt', ...
               'vmAxon_anode_tDCS_4p60V_3mA_D10um_z6mm.txt', ...            
               'vmAxon_anode_tDCS3mA_tPCS3mA_D10um_z6mm.txt', ...
               'vmAxon_anode_tDCS3mA_tPCS5mA_D10um_z6mm.txt', ...
               'vmAxon_anode_tDCS3mA_tPCS7mA_D10um_z6mm.txt'};
numScalpCases = length(fName_axRsp);

           
% brain files
fName_spikeTime = {'spikeTimes_tDCS3mA_tPCS_10Hz10msMP_EMag.txt'};
numBrainCases = length(fName_spikeTime);

%% load data

% voltage thresohlds vs. freq
numFiles = length(depthAx);
thData = cell(numFiles, 1);
for jj = 1:numFiles
    thData{jj} = load([dataDir, '/', threshFilePre, num2str(depthAx(jj)), 'mm.txt']);
end

% axon responses at scalp
axRsp = cell(numScalpCases, 1);
for k = 1:numScalpCases
    axRsp{k} = load([dataDir, '/', fName_axRsp{k}]);
end

% spike times vs. E strength for ""
spikeData = cell(numBrainCases, 1);
for k = 1:numBrainCases
    spikeData{k} = load([dataDir3, '/', fName_spikeTime{k}]);          
end

Emag = unique(spikeData{1}(:,1));
numE = length(Emag);

% synchronization for all E values
S_E = zeros(numBrainCases, numE);
T = 10; % 10 s of simulation time
for ii = 1:numBrainCases
    ii
    for jj = 1:numE

        % get rows of data for current E value
        rows_Ek = spikeData{ii}(:,1) == Emag(jj);
        M = spikeData{ii}(rows_Ek, 2:3);

        % hold spikes in a cell array
        X = matrix2cell(M, 1, 2);

        % calculate spike synchronization
        S_E(ii,jj) = ppln_spikeSync(X, T);

    end
end

%% plot - example of axonal responses for QAB

% define 1, 5, and 10 ms pulse trains
tAx = 1e-3 * axRsp{1}(:,1); % [ms => s]
tDel = 1e-3; % [ms => s]
tBuffer = 5e-3; % ""
uAx = (tAx > tDel) & tAx <= (tAx(end) - tBuffer);

% DC cases
figure;
for k = 1:3
    subplot(3, 1, k);
    plot(tAx, axRsp{k}(:,2), 'LineWidth', 3, 'Color', 'k');
    axis tight;
    xlim([tDel, tAx(end) - tBuffer]);
end

% waveforms for three DC + PC cases
fTrain = 10; % [Hz]
pw = 10e-3; % [ms => s]
indxE = [7, 11, 15];
numVal = length(indxE);
wave3 = zeros(numVal, length(tAx));
pcAmp = Emag(indxE);
dcAmp = 3;
for k = 1:numVal
    
    numCyc = round(1 / fTrain / pw);
    p = mod((tAx - tDel) .* uAx / pw, numCyc);    
    ckPos = p >= (numCyc/4 - 0.5) & p <= (numCyc/4 + 0.5);
    yBase = zeros(size(p));
    yBase(ckPos) = pcAmp(k);
    yBase(~ckPos) = 0;
    wave3(k,:) = yBase + dcAmp;  
    
end

yMax = max(pcAmp + dcAmp);
for k = 1:numVal
    
    figure;
    subplot(2, 12, 3:10);
    plot(tAx, axRsp{k+3}(:,2), 'LineWidth', 3, 'Color', 'k');
    axis tight;
    xlim([tDel, tAx(end) - tBuffer]);
    subplot(2, 12, 15:22);
    plot(tAx, wave3(k, :), 'LineWidth', 3, 'Color', rShades3(3,:));
    axis tight;
    xlim([tDel, tAx(end) - tBuffer]);
    ylim(yMax * [0,1]);

end

%% plot - transition of three states (Q => A => B) vs. current level
% Q, quiescent (not active)
% A, active (firing)
% B, pseudo block or block (not firing)

clr3 = [0, 0, 0; 0, 128, 0; 255, 0, 0] / 255;
marker = {'d', 'o', 's'};
dely = [-0.2, 0, 0.2];

indxD = [1, 3, 5];
numVal = length(indxD);

thRef = thData{2};
dI = 0.1;

figure;
hold on;
for k = 1:numVal
    
    % get thresholds for A and B
    Ith_A = round(thRef(1, indxD(k)) / ZDC, 2); % (V => mA)
    Ith_B = round(thRef(2, indxD(k)) / ZDC, 2); % (V => mA)
    
    % define three ranges (q: Q => A; a: A=> B; b: B => B)
    plot([0, Ith_A], (1 + dely(k)) * [1, 1], ['-', marker{k}], 'LineWidth', 3, ...
        'Color', clr3(1,:), 'MarkerFaceColor', clr3(1,:), 'MarkerSize', 12);
    plot([Ith_A, Ith_B], (2 + dely(k)) * [1, 1], ['-', marker{k}], 'LineWidth', 3, ...
        'Color', clr3(2,:), 'MarkerFaceColor', clr3(2,:), 'MarkerSize', 12);
    plot([Ith_B, 10], (3 + dely(k)) * [1, 1], ['-', marker{k}], 'LineWidth', 3, ...
        'Color', clr3(3,:), 'MarkerFaceColor', clr3(3,:), 'MarkerSize', 12);    
    
end
plot([3, 3], [0.5, 3.5], 'r--', 'LineWidth', 3);
hold off;
xlabel('current (mA)', 'FontSize', 30);
ylabel('State', 'FontSize', 30);
set(gca, 'FontSize', 30, 'yTick', 1:3, 'yTickLabel', {'Q', 'A', 'B'});
axis square;
ylim([0.5, 3.5]);

%% plot - nerve response for given I level

Istim = 3; % [mA]

% nerve diameter
rNerve = 1.05;
oNerve = [6; 0]; % origin of nerve [mm]

% sample uniform dists. of r [0, 1] and theta [0, 2pi)
% preload or...
rTheta_dist = load([dataDir, '/', 'radThetaDist_samp3.txt']);
% de novo sample
% rTheta_dist = lhsdesign(numAx, 2);
rUni = rTheta_dist(:,1);
thUni = 2 * pi * rTheta_dist(:,2);
% dlmwrite('radThetaDist_samp3.txt', rTheta_dist);

% uniform point picking in a disk
x = sqrt(rUni) .* cos(thUni);
y = sqrt(rUni) .* sin(thUni);
xy = [x, y];

% distance of each axon
rAx = sqrt(sum((oNerve*ones(1, numAx) + xy').^2, 1))';

% thresholds for A (col 1) and B (col 2)
IAx = zeros(numAx, 2);
for ii = 1:numDiam
    
    ro = D_cumCounts(ii)+1;
    rf = D_cumCounts(ii+1);
    
    for jj = 1:2
        
        % activation (1) and block (2) thresholds
        ith = [thData{1}(jj, ii), thData{2}(jj, ii), thData{3}(jj, ii)] / ZDC;
        IAx(ro:rf, jj) = interp1(depthAx', ith', rAx(ro:rf));
        
    end
    
end

figure;
hold on;
for k = 1:numDiam

    % get coordinates for each diameter
    ro = D_cumCounts(k)+1;
    rf = D_cumCounts(k+1);
    xD = x(ro:rf);
    yD = y(ro:rf);
    
    % check thresholds for state (Q, A, or B)
    ith_sub = IAx(ro:rf, :);
    ckA = ith_sub(:,1) <= Istim & ith_sub(:,2) > Istim;
    ckB = ith_sub(:,2) <= Istim;
    ckQ = ~(ckA | ckB);

    % size factor for plotting
    sFac = (D_val(k)/max(D_val)).^2;

    % plot active and inactive
    plot(xD(ckQ), yD(ckQ), 'o', 'MarkerSize', 16*sFac, ...
        'MarkerFaceColor', clr3(1,:), ...
        'MarkerEdgeColor', clr3(1,:), 'LineWidth', 3);    
    plot(xD(ckA), yD(ckA), 'o', 'MarkerSize', 16*sFac, ...
        'MarkerFaceColor', clr3(2,:), 'MarkerEdge', 'none');   
    plot(xD(ckB), yD(ckB), 'o', 'MarkerSize', 16*sFac, ...
        'MarkerFaceColor', clr3(3,:), 'MarkerEdge', 'none');

end
rectangle('Position', rNerve * [-1, -1, 2, 2], ...
    'Curvature', [1,1], 'LineWidth', 3);
hold off;
axis square;
axis tight;

ckA = IAx(:,1) <= Istim & IAx(:,2) > Istim;
ckB = IAx(:,2) <= Istim;
ckQ = ~(ckA | ckB);

Per_QAB = 100 * [sum(ckQ), sum(ckA), sum(ckB)] / numAx;

%% plot data - brain response, spike times and rate

figure;
hold on;
plot([Emag(1), Emag(end)], S_E(1,1) * [1,1], '--', 'LineWidth', 3, 'Color', rShades3(1,:));
plot([Emag(1), Emag(end)], [1,1], '--', 'LineWidth', 3, 'Color', 0.5*[1,1,1]);
for k = 1:numBrainCases
    plot(Emag, S_E(k,:), '-', 'LineWidth', 4, 'Color', rShades3(3,:));
end
hold off;
xlabel('E (V/m)', 'FontSize', 30);
ylabel('Synchrony', 'FontSize', 30);
axis square;
set(gca, 'FontSize', 30);
ylim([0, 1]);

%% plot data - brain response, synchronization
% DC = 3 V/m, PC = 3, 5, and 7 V/m

% extract spike times at E = 4 V/m
spikes = cell(numVal, 1);
for k =1:numVal
    tmp = spikeData{1}(:,1) == Emag(indxE(k));
    spikes{k} = matrix2cell(spikeData{1}(tmp, 2:3), 1, 2);    
end

% analyze synchronicity and entrainment strength (spike / sec)
fStim = 10;
numTrials = max(length(spikes{1}));
isi_all = cell(numVal, 1);
rad_all = cell(numVal, 1);
for ii = 1:numVal
    
    % accumulate interspike intervals for all spike trains
    isi = [];
    for jj = 1:numTrials
        isi = [isi, diff(spikes{ii}{jj})]; % inter        
    end
    
    ipi_sim1{ii} = isi;
    rad_all{ii} = 2 * pi * mod(isi, 1/fStim) / (1/fStim);
    
end

% synchronicity
for k = 1:numVal
    figure;
    polarhistogram(rad_all{k}, 100, 'Normalization', 'pdf',...
        'FaceColor', rShades3(3,:));
    set(gca, 'FontSize', 40, 'LineWidth', 3, 'rtick', (0:25:50)/100);
    rlim([0,0.5]);
end







