function [Sppln, Ds, S] = ppln_spikeDistance(t, X, fEnd)
%% Wrapper fxn for calculating bi-variate spike distance for neural ppln
% Author: Bryan Howell, PhD
% Created: 12/02/2020
%
% INPUTS:
% t, time vector (s)
% X, cell array containing spike times of each neuron / spike train
% fEnd, fraction of ends to cutoff (mitigate edge effects)
% - recommended 0.05 (cuts of 5 % of time from both ends)
%
% OUTPUT:
% S, instantaneous dissimilarity of population
% Ds, average dissimilarity of entire population
%
% References:
% Algorithm by Kruez et al., J Neurophys, 2013
% Link: scholarpedia.org/article/SPIKE-distance (algorithm summary)
%% calculate bi-variate SPIKE-distance of neural spiking population

N = length(X); % # of neurons / spike trains

% dissimilarity of all neuron pairs
pairs = nchoosek(1:N, 2);
[~, si] = sort(pairs(:,1));
pairs = pairs(si,:);
numPairs = size(pairs, 1);
S = zeros(numPairs, length(t));

for k = 1:numPairs
    S(k,:) = bivar_spikeDistance(t, X{pairs(k,1)}, X{pairs(k,2)});
end

% ppln dissimilarity
Sppln = sum(S, 1) / N / (N-1) / 2;

% cutoff end for better accuracy
iKeep = t >= t(end) * fEnd & t <= t(end) * (1 - fEnd);
tSub = t(iKeep);
Ds = trapz(tSub, Sppln(iKeep)) / (tSub(end) - tSub(1));