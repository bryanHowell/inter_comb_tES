function [S] = ppln_spikeSync(X, T)
%% Calculates time-scale independent synchrony of two spike trains.
% Author: Bryan Howell, PhD
% Created: 12/01/2020
%
% INPUTS:
% X, cell array containing spike trains of all N neurons (s)
% T, time interval of evaluation (s)
%
% OUTPUT:
% S, spike synchronization [0, 1]
% 0 => no spikes coincident
% 1 => all spikes coincident
%
% References:
% Algorithm by Kruez et al., J Neurophys, 2015
% Link: scholarpedia.org/article/Measures_of_spike_train_synchrony

%% calculate all pairwise coincidences (for i != j)

N = length(X);
M = 0; % total count of all pooled spikes
cPool = 0; % running count of coincidence counters
for ii = 1:N
    
    % each spike i of x is compared to all non-self spike trains
    nx_i = length(X{ii});
    C = zeros(N, nx_i);
    for jj = 1:N
        if(ii ~= jj)
            C(jj, :) = bivar_spikeSync(X{ii}, X{jj}, T);
        end
    end
    c_i = sum(C, 1) / (N-1);
    
    % keep running count of pooled coincident counter and spike count
    cPool = cPool + sum(c_i);
    M = M + nx_i;
    
end

S = cPool / M;

