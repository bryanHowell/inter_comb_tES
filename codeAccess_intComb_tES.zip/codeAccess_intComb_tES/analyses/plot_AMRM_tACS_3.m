%% script for plotting placebo protocols for tDCS/tACS
% Author: Bryan Howell, Ph.D.
% Created: 03/01/2021

clear;
clc;

%% path names and files

% directories
workDir = pwd;
dataDir = [workDir,'/results_scalpStim'];

% scalp files
fName_axRsp = {'vmAxon_negPol_10Hz_tACS1mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_10Hz_tACS2mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_10Hz_tACS3mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_10Hz_tACS4mA_D10um_z6mm.txt',...
               'vmAxon_negPol_1kHz10Hz_AMtACS6p5mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_1kHz10Hz_RMtACS6p0mA_D10um_z6mm.txt'};

%% read data

numCases = length(fName_axRsp);

% axon responses at scalp
axRsp = cell(numCases, 1);
for k = 1:numCases
    axRsp{k} = load([dataDir, '/', fName_axRsp{k}]);
end
% % down-sample 10 kHz case (t = 1e-3 ms => 2.5e-2 ms)
% nDownSamp = round(2.5e-2 / 1e-3);
% axRsp{4} = axRsp{4}(1:nDownSamp:end,:);


%% plot colors

% rows 1-3: black (tACS), dark green (AM-tACS), orange (RM-tACS)
clrs = [0, 0, 0; 0, 0, 0; 0, 0, 0; 0, 0, 0; 0, 78, 56; 217, 83, 25] / 255;

%% plot data - scalp response, axon APs

% define waveforms
tAx = 1e-3 * axRsp{1}(:,1); % dt = 2.5e-2, [ms => s]
tDel = 1e-3; % [ms => s]
uAx = tAx > tDel;
y = cell(numCases, 1);
y{1} = sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
y{2} = sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
y{3} = sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
y{4} = sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
y{5} = (0.5 * sin(2 * pi * 1e3 * (tAx - tDel)) + ...
    0.5 * sin(2 * pi * (1e3+10) * (tAx - tDel))) .* uAx;
y{6} = abs(sin(2 * pi * 1e3 * (tAx - tDel))) .* sin(2 * pi * 10 * (tAx - tDel)) .* uAx;
pol = -1*ones(numCases,1);
amp = [1, 2, 3, 4, 6.5, 6];

for k = 1:numCases
    
    figure;
    subplot(2, 12, 3:10);
    plot(1e-3*axRsp{k}(:,1), axRsp{k}(:,2), 'LineWidth', 3, 'Color', 'k');
    axis tight;
    ylim([-92.5, 30]);
    title(['I = ', num2str(amp(k)), ' mA']);
    subplot(2, 12, 15:22);
    plot(1e-3*axRsp{k}(:,1), pol(k)*y{k}, 'LineWidth', 3, 'Color', clrs(k,:));
    axis tight;
    ylim(1.1 * [-1,1]);

end

