%% script for plotting placebo protocols for tDCS/tACS
% Author: Bryan Howell, Ph.D.
% Created: 03/01/2021

clear;
clc;

%% path names and files

% directories
workDir = pwd;
dataDir = [workDir,'/results_placebo'];

% scalp files
fName_axRsp = {'vmAxon_anode_tDCS1mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_1kHz14Hz_AMtACS6p75mA_D10um_z6mm.txt', ...
               'vmAxon_anode_tDCS3mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_10kHz_tACS9p7mA_D10um_z6mm.txt',...
               'vmAxon_negPol_20Hz_tACS2mA_D10um_z6mm.txt',...
               'vmAxon_negPol_1kHz20Hz_AMtACS7p0mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_20Hz_tACS4mA_D10um_z6mm.txt', ...
               'vmAxon_negPol_1kHz20Hz_AMtACS7p5mA_D10um_z6mm.txt'};

% brain files
fName_spike = {'spikes_100PtNrns_tDCS1mA_anode1p1Vpm.txt', ...
               'spikes_100PtNrns_1kHz14Hz_tACS6p8mA_anode4p6Vpm.txt', ...
               'spikes_100PtNrns_tDCS4mA_anode4p4Vpm.txt', ...
               'spikes_100PtNrns_10kHz_tACS9p3mA_anode5p4Vpm.txt',...
               'spikes_100PtNrns_20Hz_tACS2mA_anode2p2Vpm.txt', ...
               'spikes_100PtNrns_1kHz20Hz_tACS7p0mA_anode4p7Vpm.txt', ...
               'spikes_100PtNrns_20Hz_tACS4mA_anode4p4Vpm.txt', ...
               'spikes_100PtNrns_1kHz20Hz_tACS7p5mA_anode5p1Vpm.txt'};


%% read data

numCases = length(fName_axRsp);

% axon responses at scalp
axRsp = cell(numCases, 1);
for k = 1:numCases
    axRsp{k} = load([dataDir, '/', fName_axRsp{k}]);
end
% % down-sample 10 kHz case (t = 1e-3 ms => 2.5e-2 ms)
% nDownSamp = round(2.5e-2 / 1e-3);
% axRsp{4} = axRsp{4}(1:nDownSamp:end,:);

% spike times vs. E strength for ""
spikeData = cell(numCases, 1);
for k = 1:numCases
    spikeData{k} = load([dataDir, '/', fName_spike{k}]);    
end

% synchronization for all E values
S_E = zeros(numCases, 1);
T = 10; % 10 s of simulation time
for ii = 1:numCases

    % hold spikes in a cell array
    X = matrix2cell(spikeData{ii}, 1, 2);

    % calculate spike synchronization
    S_E(ii) = ppln_spikeSync(X, T);

end


%% plot colors

% rows 1-3: black (tACS), dark green (AM-tACS), orange (RM-tACS)
clrs = [255, 0, 0; 0, 78, 56; 255, 0, 0; ...
    0, 0, 0; 0, 0, 0; 0, 78, 56; 0, 0, 0; 0, 78, 56] / 255;

%% plot data - scalp response, axon APs

% define waveforms
tAx = 1e-3 * axRsp{1}(:,1); % dt = 2.5e-2, [ms => s]
tAx2 = 1e-3 * axRsp{4}(:,1); % dt = 1e-3
tDel = 1e-3; % [ms => s]
uAx = tAx > tDel;
y = cell(numCases, 1);
y{1} = uAx;
y{2} = (0.5 * sin(2 * pi * 1e3 * (tAx - tDel)) + ...
    0.5 * sin(2 * pi * (1e3+14) * (tAx - tDel))) .* uAx;
y{3} = uAx;
y{4} = sin(2 * pi * 1e4 * (tAx2 - tDel)) .* (tAx2 > tDel);
y{5} = sin(2 * pi * 20 * (tAx - tDel)) .* uAx;
y{6} = (0.5 * sin(2 * pi * 1e3 * (tAx - tDel)) + ...
    0.5 * sin(2 * pi * (1e3+20) * (tAx - tDel))) .* uAx;
y{7} = sin(2 * pi * 20 * (tAx - tDel)) .* uAx;
y{8} = (0.5 * sin(2 * pi * 1e3 * (tAx - tDel)) + ...
    0.5 * sin(2 * pi * (1e3+20) * (tAx - tDel))) .* uAx;
amp = [1, 6.75, 3, 9.3, 2, 7, 4, 7.5];
pol = -1*ones(numCases,1);
pol([1,3]) = 1;

for k = 1:numCases
    
    figure;
    subplot(2, 12, 3:10);
    plot(1e-3*axRsp{k}(:,1), axRsp{k}(:,2), 'LineWidth', 3, 'Color', 'k');
    axis tight;
    ylim([-88, 30]);
    title(['I = ', num2str(amp(k)), ' mA']);
    subplot(2, 12, 15:22);
    plot(1e-3*axRsp{k}(:,1), pol(k)*y{k}, 'LineWidth', 3, 'Color', clrs(k,:));
    axis tight;
    ylim(1.1 * [-1,1]);

end

%% PLOT, rastor plots
% 1-4 => regular rastor plots
% 4-8 => show expected timing of synchronization

% time vector for simulations [s]
fStim = 20;
fBase = 1e3;
dt = (1/fBase)/10;
tf = 10;
t_delay = 0.25;
t = 0:dt:tf;
u = t > t_delay;

% where to plot waveforms
yOff = -7;
yScale = 5;
o = ones(size(t));

% running firing frequency
nBin = 40;
tBin = T / nBin;
isi = ones(4, nBin);
nNrn = 100;
for k = 1:4
    isi(k,:) = histcounts(spikeData{k}(:,2), nBin) / tBin / nNrn;
end

% rastors for 1-4
for k = 1:4
    
    figure;
    subplot(3, 12, [3:10, 15:22]);
    hold on;
    plot(spikeData{k}(:,2), spikeData{k}(:,1), 'ko', 'MarkerFaceColor', 'k', 'Color', 'k');
    plot([0,T], yOff * [1,1], 'k', 'LineWidth', 4, 'Color', clrs(k,:));    
    hold off;
    ylabel('trials', 'FontSize', 30); 
    set(gca, 'FontSize', 30, 'yTick', [1,25:25:100]);
    xlim([2,6]);
    ylim([-13, 101]);
    
    subplot(3, 12, 27:34);
    hold on;    
    if(k == 1)
        plot([0, T], 1.7 * [1,1], '-', 'LineWidth', 3, 'Color', 0.75*[1,1,1]);
    end
    plot(tBin:tBin:T, isi(k,:), 'LineWidth', 3, 'Color', clrs(k,:));    
    hold off;
    xlim([2,6]);
    ylim([1,8]);
    
end

% inputs
y5 = sin(2 * pi * 20 * (t - t_delay)) .* u;
y6 = (0.5 * sin(2 * pi * 1e3 * (t - t_delay)) + ...
    0.5 * sin(2 * pi * (1e3+20) * (t - t_delay))) .* u;
y7 = sin(2 * pi * 20 * (t - t_delay)) .* u;
y8 = (0.5 * sin(2 * pi * 1e3 * (t - t_delay)) + ...
    0.5 * sin(2 * pi * (1e3+20) * (t - t_delay))) .* u;
yStim = [y5; y6; y7; y8];


% highlight synchronization limits +- 30 deg. from expected peak time
tMin = (0.25 + 0.25 / fStim):(1 / fStim):10; % tACS
tMin2 = (0.25 + 1 / fStim):(1 / fStim):10; % AM-tACS
dt30 = (30 / 180 * pi) / 2 / pi / fStim;

for k = 5:8
    
    figure;
    subplot(3, 12, [3:10, 15:22]);
    hold on;
    
    if(mod(k,2) ~= 0)
        
        for jj = 1:length(tMin)
            xL = tMin(jj) - dt30;
            xR = tMin(jj) + dt30;     
            fill([xL, xR, xR, xL], [-13, -13, 101, 101], 0.85*[1,1,1], ...
            'LineStyle', 'none');
        end
                
    else
        
        for jj = 1:length(tMin2)
            xL = tMin2(jj) - dt30;
            xR = tMin2(jj) + dt30;
            fill([xL, xR, xR, xL], [-13, -13, 101, 101], 0.85*[1,1,1], ...
            'LineStyle', 'none');
        end        
        
    end
    plot(spikeData{k}(:,2), spikeData{k}(:,1), 'ko', 'MarkerFaceColor', 'k', 'Color', 'k');
    plot(t, yScale * yStim(k-4, :) + yOff, 'k', 'LineWidth', 4, 'Color', clrs(k,:));    
    hold off;
    ylabel('trials', 'FontSize', 30); 
    set(gca, 'FontSize', 24, 'yTick', [1,25:25:100]);
    xlim([3,4]);
    ylim([-13, 101]);
    
end

%% plot data - brain response, synchronization

numTrials = max(spikeData{1}(:,1));

isi_all = cell(4, 1);
rad_all = cell(4, 1);
for ii = 5:8
    
    % accumulate interspike intervals for all spike trains
    tmp_isi = [];
    for jj = 1:numTrials
        getTrial = spikeData{ii}(:,1) == jj;
        tmp_isi = [tmp_isi; diff(spikeData{ii}(getTrial,2))]; % inter        
    end
    
    isi_all{ii-4} = tmp_isi;
    rad_all{ii-4} = 2 * pi * mod(tmp_isi, 1/fStim) / (1/fStim);
    
end

% synchronicity
for k = 1:4
    figure;
    polarhistogram(rad_all{k}, 100, 'Normalization', 'pdf',...
        'FaceColor', clrs(k+4,:));
    set(gca, 'FontSize', 40, 'LineWidth', 3, 'rtick', (0:25:50)/100);
    rlim([0,0.5]);
end


